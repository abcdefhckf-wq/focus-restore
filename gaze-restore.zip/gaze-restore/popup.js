/**
 * popup.js — 設定、啟動/停止、語言（含 Google 翻譯）、閱讀資料匯出
 * 設定寫入 chrome.storage.local；content.js 以 storage.onChanged 即時套用。
 */
const $ = (id) => document.getElementById(id);
const msg = (s) => { $('msg').textContent = s || ''; };
const ANGLES = ['front0', 'left15', 'left30', 'left45', 'right15', 'right30', 'right45', 'down15', 'up15'];
let cfg = { ...GR_DEFAULTS };
let tabId = null, tabUrl = '', isViewer = false;
const viewerUrl = chrome.runtime.getURL('viewer.html');

(async function init() {
  cfg = await chrome.storage.local.get(GR_DEFAULTS);
  chrome.storage.local.remove('mode');            // 已移除受試組別：清掉舊版留下的設定
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  tabId = tab && tab.id; tabUrl = (tab && tab.url) || '';
  isViewer = tabUrl.startsWith(viewerUrl);

  // PDF / 本機檔案
  $('rowPdfCur').hidden = !(/\.pdf([?#]|$)/i.test(tabUrl) && !isViewer);
  if (tabUrl.startsWith('file:')) {
    let ok = false;
    try { ok = await chrome.extension.isAllowedFileSchemeAccess(); } catch (_) { /* ignore */ }
    $('fileBox').hidden = ok;                        // 本機網頁需要「允許存取檔案網址」
  }
  $('btnPdfPick').addEventListener('click', () => { chrome.tabs.create({ url: viewerUrl }); window.close(); });
  $('btnPdfCur').addEventListener('click', () => { chrome.tabs.create({ url: viewerUrl + '?file=' + encodeURIComponent(tabUrl) }); window.close(); });
  $('btnExtSettings').addEventListener('click', () => { chrome.tabs.create({ url: 'chrome://extensions/?id=' + chrome.runtime.id }); window.close(); });

  // 語言選單
  for (const [code, name] of GR_LANGS) $('language').add(new Option(name, code));
  $('language').value = cfg.language;
  await applyLanguage(cfg.language);

  for (const k of ['lostSec', 'angleDeg', 'headAngleDeg', 'awayDeg', 'circleCm', 'opacity', 'color', 'subjectId', 'distanceCm', 'screenDiagIn',
                   'calibMode', 'barCount', 'llmProvider', 'llmEndpoint', 'llmModel', 'llmApiKey']) $(k).value = cfg[k];
  $('useLLM').checked = !!cfg.useLLM;
  $('lockOnBlur').checked = !!cfg.lockOnBlur;
  buildAngles(); renderValues(); renderPreview();

  for (const k of ['lostSec', 'angleDeg', 'headAngleDeg', 'awayDeg', 'circleCm', 'opacity', 'distanceCm', 'barCount']) $(k).addEventListener('input', () => save(k, Number($(k).value)));
  $('screenDiagIn').addEventListener('input', () => save('screenDiagIn', Number($('screenDiagIn').value) || 14));
  for (const k of ['color', 'subjectId', 'angleLabel', 'calibMode', 'llmProvider', 'llmEndpoint', 'llmModel', 'llmApiKey']) $(k).addEventListener('input', () => save(k, $(k).value));
  $('useLLM').addEventListener('change', () => save('useLLM', $('useLLM').checked));
  $('lockOnBlur').addEventListener('change', () => save('lockOnBlur', $('lockOnBlur').checked));
  $('language').addEventListener('change', async () => { save('language', $('language').value); await applyLanguage($('language').value); });

  updateCalibUi();
  $('calibMode').addEventListener('input', updateCalibUi);
  $('btnToggle').addEventListener('click', toggle);
  $('btnCalib').addEventListener('click', () => send({ type: 'GR_CALIBRATE' }).then(() => window.close()));
  $('btnAuth').addEventListener('click', authorizeEndpoint);
  $('btnExport').addEventListener('click', exportExcel);
  $('btnAcc').addEventListener('click', async () => { await send({ type: 'GR_ACCURACY' }); window.close(); });
  $('btnClear').addEventListener('click', clearTrials);

  refreshStatus(); refreshCount();
  grMaybeStartTour();                              // 第一次安裝後才會出現的新手教學
})();

/** 只選「9 點」時，進度條數量沒有意義 → 隱藏；選「隨機」或「進度條」才顯示 */
function updateCalibUi() { $('barCountField').hidden = $('calibMode').value === 'points'; }

function save(k, v) { cfg[k] = v; chrome.storage.local.set({ [k]: v }); renderValues(); renderPreview(); }

/* ── 語言：全部內建，選了立即生效（不需要任何翻譯 API）── */
async function applyLanguage(lang) {
  await grLoadLang(lang);
  document.documentElement.lang = lang;
  document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
  applyI18n();
}

function applyI18n() {
  document.querySelectorAll('[data-i18n]').forEach((el) => { el.textContent = t(el.dataset.i18n); });
  document.querySelectorAll('[data-i18n-ph]').forEach((el) => { el.placeholder = t(el.dataset.i18nPh); });
  document.querySelectorAll('[data-i18n-aria]').forEach((el) => { el.setAttribute('aria-label', t(el.dataset.i18nAria)); });
  document.title = t('title');
  buildAngles(); renderValues();
  if (typeof refreshStatus === 'function' && tabId != null) { refreshStatus(); refreshCount(); }
}

function buildAngles() {
  const sel = $('angleLabel'), cur = cfg.angleLabel;
  sel.innerHTML = '';
  for (const a of ANGLES) sel.add(new Option(t('ang_' + a), a));
  sel.value = ANGLES.includes(cur) ? cur : 'front0';
}

function renderValues() {
  $('lostSecV').textContent = cfg.lostSec + ' s';
  $('angleDegV').textContent = cfg.angleDeg + '°';
  $('headAngleDegV').textContent = cfg.headAngleDeg + '°';
  $('awayDegV').textContent = cfg.awayDeg + '°';
  $('circleCmV').textContent = cfg.circleCm + ' cm';
  $('opacityV').textContent = Math.round(cfg.opacity * 100) + '%';
}

/** 預覽：圓心 alpha = 透明度，外圈 = 透明度 ÷ 1.5（與頁面上的規則相同） */
function renderPreview() {
  const n = parseInt(cfg.color.slice(1), 16), p = $('preview');
  p.style.setProperty('--rgb', `${(n >> 16) & 255} ${(n >> 8) & 255} ${n & 255}`);
  p.style.setProperty('--ac', cfg.opacity);
  p.style.setProperty('--ar', cfg.opacity / 1.5);
}

/* ── 啟動 / 停止 ── */
async function send(m) { try { return await chrome.tabs.sendMessage(tabId, m); } catch (_) { return null; } }

async function refreshStatus() {
  const r = await send({ type: 'GR_PING' });
  const on = !!(r && r.state && r.state !== 'OFF');
  $('dot').className = 'dot' + (on ? (r.paused ? ' paused' : ' on') : '');
  $('statusText').textContent = on ? (r.paused ? t('statusPaused') : t('statusOn', { state: r.state }))
    : (r && r.lastError ? t('statusFailed', { err: r.lastError }) : t('statusOff'));
  $('btnToggle').textContent = on ? t('btnStop') : t('btnStart');
  $('btnCalib').disabled = !on;
  $('btnAcc').disabled = !on;
}

async function toggle() {
  msg('');
  const r = await send({ type: 'GR_PING' });
  if (isViewer && !r) { msg(t('viewerToolbarHint')); return; }     // PDF 閱讀器是外掛自己的頁面，用它工具列上的按鈕控制
  if (r && r.state && r.state !== 'OFF') { await send({ type: 'GR_STOP' }); return refreshStatus(); }
  try {
    if (!r) {   // 只在使用者按「啟動」的分頁注入（activeTab），不會在所有網頁常駐
      await chrome.scripting.insertCSS({ target: { tabId }, files: ['styles.css'] });
      await chrome.scripting.executeScript({ target: { tabId }, files: ['shared.js', 'i18n.js', 'content.js'] });
      await chrome.scripting.executeScript({ target: { tabId }, world: 'MAIN', files: ['lib/webgazer.js', 'gaze-bridge.js'] });
    }
    await send({ type: 'GR_START' });
    await new Promise((res) => setTimeout(res, 1500));
    await refreshStatus();
    const st = await send({ type: 'GR_PING' });
    if (st && st.state && st.state !== 'OFF') window.close();
    else msg((st && st.lastError) || t('startFailGeneric'));
  } catch (e) { msg(t('injectFail', { err: e.message })); }
}

async function authorizeEndpoint() {
  try {
    const origin = new URL(cfg.llmEndpoint).origin + '/*';
    const ok = await chrome.permissions.request({ origins: [origin] });
    msg(ok ? t('authDone', { o: origin }) : t('authDenied'));
  } catch (e) { msg(t('badEndpoint')); }
}

/* ── 實驗資料 ── */
async function refreshCount() {
  const { trials = [] } = await chrome.storage.local.get('trials');
  $('trialCount').textContent = t('dataCount', { a: trials.length });
}

/** 匯出 Excel（.xlsx）：摘要、中斷紀錄、設定與裝置、欄位說明四個工作表（原本的 CSV 在 Excel 開啟會變亂碼） */
async function exportExcel() {
  msg('');
  const { trials = [] } = await chrome.storage.local.get('trials');
  if (!trials.length) return msg(t('noData'));
  try {
    const rep = grBuildReport(trials, cfg.language, (a) => (a && ANGLES.includes(a) ? t('ang_' + a) : (a || '')));
    const blob = grXlsx(rep.sheets);
    const d = new Date(), p = (n) => String(n).padStart(2, '0');
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `${rep.fileBase}-${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}.xlsx`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  } catch (e) { console.error(e); msg(String(e && e.message || e)); }
}

async function clearTrials() {
  if (!confirm(t('confirmClear'))) return;
  await chrome.storage.local.remove(['trials', 'accuracy']);
  refreshCount();
}
