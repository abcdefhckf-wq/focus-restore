/**
 * shared.js — 設定預設值（popup / content / background 共用）
 * 以 var 宣告，避免重複注入時出現 "already declared" 錯誤。
 */
var GR_DEFAULTS = {
  // ── 中斷判定（對應論文「安全閥值」）────────────────────
  lostSec: 2,            // 視線消失偵測：臉部/視線連續消失超過幾秒 → True
  headAngleDeg: 30,      // 動作軌跡偵測：頭部轉動（左右/俯仰）相對校準基準的角度閥值
  awayDeg: 18,           // 視線方向偏離：頭部轉向 + 眼睛轉向合成的角度閥值（只有眼睛轉走、頭不動也會偵測）
  angleDeg: 3,           // 動作軌跡偵測：視線超出視窗邊界的「視角」閥值（度）；0 = 一碰到邊界就算

  // ── 高光（對應論文「功能客製化」）──────────────────────
  opacity: 0.6,          // 高光中心的透明度（外圈 = 此值 ÷ 1.5，即中心比外圈亮 50%）
  circleCm: 4,           // 高光圓形直徑（公分），以螢幕尺寸換算成像素
  color: '#FFE45C',      // 高光顏色

  // ── 實驗條件（自變數：眼睛與鏡頭距離、使用者角度）──────
  subjectId: '',         // 受試者編號
  distanceCm: 60,        // 眼睛與筆電鏡頭的實際距離（公分，用捲尺量）
  angleLabel: 'front0',  // 使用者相對鏡頭的角度代碼（front0/left15/left30/left45/right15/right30/right45/down15/up15）
  screenDiagIn: 14,      // 螢幕對角線尺寸（吋），用來把像素換算成公分/視角

  // ── 校準 ───────────────────────────────────────────────
  calibMode: 'random',   // 'random'（每次隨機）/ 'bars'（進度條）/ 'points'（9 點，每點 3 下）
  barCount: 4,           // 進度條數量（1~4）：1 水平、2 垂直、3 底部水平、4 外斜

  // ── 鎖定、語言 ─────────────────────────────────────────
  lockOnBlur: false,     // true：切換到其他視窗（失焦）也暫停；預設只在「分頁切到背景」時暫停
  language: 'zh-TW',     // 介面語言（全部內建，選了立即生效，不需要任何翻譯 API）

  // ── LLM 語意校準 ───────────────────────────────────────
  useLLM: true,
  llmProvider: 'openai', // 'openai'（含所有 OpenAI 相容端點）或 'anthropic'
  llmEndpoint: 'https://api.openai.com/v1/chat/completions',
  llmModel: 'gpt-4o-mini',
  llmApiKey: ''          // ⚠ 僅存在 chrome.storage.local；正式部署請改走自己的後端代理
};
