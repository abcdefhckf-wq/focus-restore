/**
 * gaze-bridge.js — 注入「頁面主世界（MAIN world）」，與 lib/webgazer.js 同一個 JS 環境
 *
 * 為何需要橋接？
 *  WebGazer（含其 MediaPipe FaceMesh 模型）會在頁面中建立 <video>、載入 wasm 與 script，
 *  必須與頁面共用同一個 JS 世界才能正常運作；但 content.js 在「隔離世界」，
 *  兩邊只能透過 window.postMessage 溝通：
 *     content.js ──cmd──▶ gaze-bridge.js（start / stop / preview）
 *     content.js ◀──evt── gaze-bridge.js（ready / gaze / error）
 *
 * 安全註記：頁面上的其他腳本理論上能偽造這些訊息；本研究為受控實驗環境，故僅檢查 event.source。
 */
(() => {
  if (window.__GR_BRIDGE__) return;
  window.__GR_BRIDGE__ = true;

  let running = false;
  let readyTimer = null;

  const post = (type, payload = {}) =>
    window.postMessage({ __gr: 'evt', type, ...payload }, '*');

  window.addEventListener('message', (e) => {
    if (e.source !== window || !e.data || e.data.__gr !== 'cmd') return;
    const m = e.data;
    if (m.cmd === 'start') start(m);
    else if (m.cmd === 'stop') stop();
    else if (m.cmd === 'preview') setPreview(!!m.on);
    else if (m.cmd === 'exportModel') post('model', { model: exportModel() });
    else if (m.cmd === 'importModel') post('modelLoaded', { n: importModel(m.model) });
    // 拼圖校準：把「已知螢幕座標」當作訓練樣本餵給 WebGazer（使用者的眼睛正跟著拼圖移動）
    else if (m.cmd === 'train') {
      try { webgazer.recordScreenPosition(m.x, m.y, 'click'); } catch (_) { /* ignore */ }
    }
    // 準確度測試期間關閉「滑鼠移動即訓練」，避免游標位置污染測量
    else if (m.cmd === 'mouseTrain') {
      try { m.on ? webgazer.addMouseEventListeners() : webgazer.removeMouseEventListeners(); } catch (_) { /* ignore */ }
    }
  });

  function start(m) {
    if (running) return;
    if (typeof webgazer === 'undefined') {
      post('error', { code: 'nolib', message: 'WebGazer not loaded' });
      return;
    }
    try {
      // MediaPipe 模型檔放在擴充功能內（lib/mediapipe/face_mesh），不依賴 CDN
      if (m.faceMeshPath) webgazer.params.faceMeshSolutionPath = m.faceMeshPath;

      webgazer
        .setRegression('ridge')            // 以「點擊 / 游標」為訓練樣本的 ridge 回歸
        .saveDataAcrossSessions(false)     // 關掉 WebGazer 自己的儲存（它只在滑鼠點擊時才存，我們的校準不是點擊）；改由 content.js 以 exportModel/importModel 管理
        .setGazeListener((data /*, elapsed */) => {
          // data === null 代表「這一幀偵測不到臉/眼睛」→ 供 content.js 做「視線消失偵測」
          post('gaze', {
            pose: data ? poseFeatures() : null,   // 頭部/身體姿態特徵（動作軌跡偵測用）
            face: !!data,
            x: data ? data.x : null,
            y: data ? data.y : null,
            t: performance.now()
          });
        });

      webgazer.begin(() => post('error', { code: 'camera', message: 'camera unavailable' }));
      running = true;

      // 輪詢 isReady()，就緒後通知 content.js
      const t0 = Date.now();
      readyTimer = setInterval(() => {
        if (webgazer.isReady && webgazer.isReady()) {
          clearInterval(readyTimer);
          webgazer.applyKalmanFilter(true);  // 卡爾曼濾波，降低視線座標微幅抖動
          setPreview(true);
          post('ready');
          // 鏡頭規格（解析度、每秒張數、名稱）：記錄到實驗資料，分析時可看出差異是否來自筆電鏡頭
          setTimeout(() => {
            try {
              const v = document.getElementById('webgazerVideoFeed');
              const tr = v && v.srcObject && v.srcObject.getVideoTracks ? v.srcObject.getVideoTracks()[0] : null;
              const st = tr && tr.getSettings ? tr.getSettings() : {};
              post('cam', { w: (v && v.videoWidth) || st.width || 0, h: (v && v.videoHeight) || st.height || 0, fps: st.frameRate || 0, label: tr ? tr.label : '' });
            } catch (_) { /* 取不到就不記 */ }
          }, 800);
        } else if (Date.now() - t0 > 30000) {
          clearInterval(readyTimer);
          post('error', { code: 'timeout', message: 'init timeout' });
        }
      }, 300);
    } catch (err) {
      post('error', { message: String(err && err.message || err) });
    }
  }

  /**
   * 由 FaceMesh 特徵點估計「頭部/身體姿態」與「眼睛相對頭部的方向」，供 content.js 偵測離開。
   *   yawIdx   ：鼻尖在左右臉頰之間的偏移比例（-1~1），頭左右轉時改變
   *   pitchIdx ：鼻尖在「眼線～下巴」之間的垂直位置比例，抬頭/低頭時改變
   *   cx, cy   ：臉中心在影像中的位置（身體平移）
   *   faceW    ：臉寬（影像像素），身體前傾/後仰時改變（距離變化）
   *   eyeX/eyeY：虹膜中心相對眼睛中心的位移（以半個眼寬為單位）→ 「只有眼睛轉走、頭不動」的關鍵訊號
   *   open     ：眼睛開闔度（上下眼瞼距離 / 眼寬）→ 閉眼、低頭看手機時變小
   * 點位索引（MediaPipe FaceMesh，refineLandmarks 開啟後共 478 點）：
   *   鼻尖 1、左/右臉頰 234/454、額頭 10、下巴 152
   *   右眼：外角 33、內角 133、上眼瞼 159、下眼瞼 145、虹膜中心 468
   *   左眼：外角 263、內角 362、上眼瞼 386、下眼瞼 374、虹膜中心 473
   */
  function eyeFeature(p, iris, a, b, up, lo) {
    const A = p[a], B = p[b], I = p[iris], U = p[up], L = p[lo];
    const w = Math.hypot(B[0] - A[0], B[1] - A[1]) || 1;
    return {
      rx: (I[0] - (A[0] + B[0]) / 2) / (w / 2),
      ry: (I[1] - (U[1] + L[1]) / 2) / (w / 2),
      open: Math.abs(L[1] - U[1]) / w
    };
  }

  function poseFeatures() {
    try {
      const tr = webgazer.getTracker && webgazer.getTracker();
      const p = tr && tr.getPositions && tr.getPositions();
      if (!p || p.length < 468) return null;
      const nose = p[1], lc = p[234], rc = p[454], chin = p[152], fore = p[10], le = p[33], re = p[263];
      const dL = Math.abs(nose[0] - lc[0]), dR = Math.abs(rc[0] - nose[0]);
      const eyeY = (le[1] + re[1]) / 2;
      const out = {
        yawIdx: (dL - dR) / (dL + dR || 1),
        pitchIdx: (nose[1] - eyeY) / ((chin[1] - eyeY) || 1),
        cx: (lc[0] + rc[0]) / 2,
        cy: (fore[1] + chin[1]) / 2,
        faceW: Math.hypot(rc[0] - lc[0], rc[1] - lc[1]),
        eyeX: null, eyeY: null, open: null
      };
      if (p.length >= 478) {           // 有虹膜點才計算；沒有就只剩頭部姿態訊號
        const r = eyeFeature(p, 468, 33, 133, 159, 145), l = eyeFeature(p, 473, 263, 362, 386, 374);
        out.eyeX = (r.rx + l.rx) / 2; out.eyeY = (r.ry + l.ry) / 2; out.open = (r.open + l.open) / 2;
      }
      return out;
    } catch (_) { return null; }
  }

  /**
   * 校準資料的匯出／匯入。
   * WebGazer 預測只用三組資料：眼睛特徵向量、對應的螢幕 x、y（ridge 回歸）。
   * 我們只存這三組（約 700 筆 × 120 維，數百 KB），不存完整的眼睛影像（那會大上十倍）。
   * 三個 DataWindow 以相同次數 push，所以即使環狀緩衝區繞過一圈，彼此的配對仍然一致。
   */
  function exportModel() {
    try {
      const r = webgazer.getRegression()[0];
      return { fx: r.eyeFeaturesClicks.data.slice(), x: r.screenXClicksArray.data.slice(), y: r.screenYClicksArray.data.slice() };
    } catch (_) { return null; }
  }

  function importModel(m) {
    try {
      if (!m || !m.fx || !m.fx.length) return 0;
      const r = webgazer.getRegression()[0];
      r.init();                                   // 清空後重新灌入，結果是確定的（不會重複累加）
      for (let i = 0; i < m.fx.length; i++) {
        r.eyeFeaturesClicks.push(m.fx[i]); r.screenXClicksArray.push(m.x[i]); r.screenYClicksArray.push(m.y[i]);
      }
      return m.fx.length;
    } catch (_) { return 0; }
  }

  function stop() {
    clearInterval(readyTimer);
    if (!running) return;
    try { webgazer.end(); } catch (_) { /* ignore */ }
    running = false;
  }

  /** 校準時顯示鏡頭預覽與預測點；校準完成後隱藏，避免干擾閱讀 */
  function setPreview(on) {
    try {
      webgazer.showVideoPreview(on);
      webgazer.showPredictionPoints(on);
      webgazer.showFaceOverlay(on);
      webgazer.showFaceFeedbackBox(on);
    } catch (_) { /* ignore */ }
  }
})();
