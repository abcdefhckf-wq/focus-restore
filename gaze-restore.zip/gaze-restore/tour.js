/**
 * tour.js — 新手教學（只在第一次安裝外掛後出現一次）
 * background.js 在 onInstalled(reason = 'install') 時寫入 tourPending: true；
 * popup 開啟時若看到這個旗標就依序聚光介紹各功能，看完或略過後清除旗標，之後不再出現。
 */
const GR_TOUR_STEPS = [
  { sel: '#btnToggle', key: 'tour1' },
  { sel: '#pdfBox', key: 'tour2' },
  { sel: '#condCore', key: 'tour3' },
  { sel: '#preview', key: 'tour4' },
  { sel: '.data', key: 'tour5' }
];

async function grMaybeStartTour() {
  const { tourPending } = await chrome.storage.local.get('tourPending');
  if (tourPending) grPickLanguage().then(grStartTour);
}

/**
 * 強制選語言：全畫面語言按鈕，必須點一個才會進入教學（沒有略過、Esc 無效）。
 * 預設停在跟瀏覽器一致的語言上；方向鍵移動、Enter 或點擊選定。
 */
function grPickLanguage() {
  return new Promise((resolve) => {
    const sel = document.getElementById('language');
    const box = document.createElement('div');
    box.className = 'langpick';
    box.setAttribute('role', 'dialog'); box.setAttribute('aria-modal', 'true'); box.setAttribute('aria-label', 'Language');
    box.innerHTML =
      '<svg class="langpick-globe" viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9.5"/><path d="M2.5 12h19M12 2.5c2.6 2.7 3.9 5.9 3.9 9.5s-1.3 6.8-3.9 9.5M12 2.5C9.4 5.2 8.1 8.4 8.1 12s1.3 6.8 3.9 9.5"/></svg>' +
      '<div class="langpick-title">請選擇語言 · Choose your language</div><div class="langpick-grid"></div>';
    const grid = box.querySelector('.langpick-grid');
    const btns = GR_LANGS.map(([code, name]) => {
      const b = document.createElement('button');
      b.type = 'button'; b.textContent = name; b.lang = code; b.dataset.code = code;
      b.addEventListener('click', () => choose(code));
      grid.appendChild(b);
      return b;
    });
    const choose = (code) => {
      sel.value = code;
      sel.dispatchEvent(new Event('change'));          // 交給 popup 原本的流程：存設定、換介面語言
      document.removeEventListener('keydown', onKey, true);
      box.remove();
      grLoadLang(code).then(resolve);
    };
    // 方向鍵在 2 欄格子間移動；Esc 不關閉（一定要選）
    const onKey = (e) => {
      const i = btns.indexOf(document.activeElement);
      const move = { ArrowLeft: -1, ArrowRight: 1, ArrowUp: -2, ArrowDown: 2 }[e.key];
      if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); }
      else if (move != null) { e.preventDefault(); const j = (i < 0 ? 0 : i) + move; if (btns[j]) btns[j].focus(); }
      else if (e.key === 'Tab') { e.preventDefault(); const j = ((i < 0 ? 0 : i) + (e.shiftKey ? -1 : 1) + btns.length) % btns.length; btns[j].focus(); }
    };
    document.addEventListener('keydown', onKey, true);
    document.body.appendChild(box);
    (btns.find((b) => b.dataset.code === sel.value) || btns[0]).focus();
  });
}

function grStartTour() {
  let i = 0;
  const root = document.createElement('div');
  root.className = 'tour';
  root.innerHTML =
    '<div class="tour-hole"></div>' +
    '<div class="tour-bubble" role="dialog" aria-modal="true" aria-live="polite">' +
    '  <div class="tour-step"></div><div class="tour-text"></div>' +
    '  <div class="tour-btns"><button class="tour-skip"></button><button class="tour-next"></button></div>' +
    '</div>';
  document.body.appendChild(root);
  const hole = root.querySelector('.tour-hole'), bubble = root.querySelector('.tour-bubble');
  const next = root.querySelector('.tour-next'), skip = root.querySelector('.tour-skip');

  const finish = () => {
    chrome.storage.local.remove('tourPending');
    removeEventListener('resize', place); removeEventListener('scroll', place, true);
    document.removeEventListener('keydown', onKey, true);
    root.remove();
    window.scrollTo(0, 0);
  };
  const show = () => {
    const s = GR_TOUR_STEPS[i], target = document.querySelector(s.sel);
    if (!target || target.offsetParent === null) { if (++i < GR_TOUR_STEPS.length) return show(); return finish(); }
    root.querySelector('.tour-step').textContent = `${i + 1} / ${GR_TOUR_STEPS.length}`;
    root.querySelector('.tour-text').innerHTML = grTourHtml(t(s.key));
    skip.textContent = t('tourSkip');
    skip.hidden = i === GR_TOUR_STEPS.length - 1;
    next.textContent = i === GR_TOUR_STEPS.length - 1 ? t('tourDone') : t('tourNext');
    target.scrollIntoView({ block: 'center', behavior: 'instant' });
    if (s.sel === '#btnToggle') window.scrollTo(0, 0);
    place();
    next.focus();
  };
  // 聚光圈 + 說明框跟著目標元素（捲動、視窗大小改變時重新定位）
  function place() {
    const target = document.querySelector(GR_TOUR_STEPS[i].sel);
    if (!target) return;
    const r = target.getBoundingClientRect(), pad = 6, vw = innerWidth, vh = innerHeight;
    Object.assign(hole.style, { left: r.left - pad + 'px', top: r.top - pad + 'px', width: r.width + pad * 2 + 'px', height: r.height + pad * 2 + 'px' });
    const bh = bubble.offsetHeight, gap = 16;
    const below = r.bottom + pad + gap + bh <= vh || r.top < vh - r.bottom;
    bubble.classList.toggle('up', !below);
    let top = below ? r.bottom + pad + gap : r.top - pad - gap - bh;
    top = Math.max(8, Math.min(vh - bh - 8, top));
    bubble.style.top = top + 'px';
    const cx = Math.max(24, Math.min(vw - 24, r.left + r.width / 2));
    bubble.style.setProperty('--ax', cx - bubble.getBoundingClientRect().left + 'px');
  }
  function onKey(e) {
    if (e.key === 'Escape') { e.preventDefault(); finish(); }
    else if ((e.key === 'Enter' || e.key === 'ArrowRight')) { e.preventDefault(); next.click(); }
  }
  next.addEventListener('click', () => { if (++i < GR_TOUR_STEPS.length) show(); else finish(); });
  skip.addEventListener('click', finish);
  root.addEventListener('click', (e) => { if (e.target === root) next.click(); });   // 點暗處也能前進
  addEventListener('resize', place); addEventListener('scroll', place, true);
  document.addEventListener('keydown', onKey, true);
  show();
}

/** 文字中 [[重點]] 以橘色強調；其餘一律當純文字處理 */
function grTourHtml(s) {
  const esc = (x) => x.replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  return esc(s).replace(/\[\[(.+?)\]\]/g, '<b>$1</b>');
}
