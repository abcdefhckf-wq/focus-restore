/**
 * viewer.js — 外掛自己的 PDF 閱讀器（以 Mozilla PDF.js 渲染，Apache-2.0）
 *
 * 為什麼需要它？
 *  - Chrome 內建的 PDF 檢視器是獨立的內建擴充功能，PDF 內容也不是網頁文字，外掛讀不到。
 *  - PDF.js 會把 PDF 渲染成「畫面 + 透明的文字層（<span>）」。文字層是真正的 DOM 文字，
 *    所以 content.js 的 caretPositionFromPoint、句子切分、圓形高光、LLM 校準都能照常運作。
 *  - 本機檔案用「選擇檔案」或拖曳開啟，不需要「允許存取檔案網址」權限。
 */
import * as pdfjsLib from './pdfjs/build/pdf.min.mjs';
import { EventBus, PDFLinkService, PDFViewer } from './pdfjs/web/pdf_viewer.mjs';

const $ = (id) => document.getElementById(id);
const base = chrome.runtime.getURL('');
pdfjsLib.GlobalWorkerOptions.workerSrc = base + 'pdfjs/build/pdf.worker.min.mjs';

/* ── i18n ── */
async function loadLang() {
  const { language } = await chrome.storage.local.get({ language: 'zh-TW' });
  await grLoadLang(language);
  document.documentElement.lang = language;
  document.querySelectorAll('[data-i18n]').forEach((el) => { el.textContent = t(el.dataset.i18n); });
  refreshPage(); refreshStatus();
}
chrome.storage.onChanged.addListener((ch) => { if (ch.language) loadLang(); });

/* ── PDF.js ── */
const container = $('viewerContainer');
const eventBus = new EventBus();
const linkService = new PDFLinkService({ eventBus });
const pdfViewer = new PDFViewer({ container, viewer: $('viewer'), eventBus, linkService, textLayerMode: 1 });
linkService.setViewer(pdfViewer);
let pdfDoc = null;

eventBus.on('pagesinit', () => { pdfViewer.currentScaleValue = 'page-width'; });
eventBus.on('pagechanging', refreshPage);
eventBus.on('textlayerrendered', () => { document.body.dataset.pdfReady = '1'; });   // 測試與除錯用
function refreshPage() {
  $('pageInfo').textContent = pdfDoc ? t('pdfPage', { n: pdfViewer.currentPageNumber, total: pdfDoc.numPages }) : '';
}

function showNotice(text, buttons = []) {
  $('noticeText').textContent = text;
  const box = $('noticeBtns'); box.textContent = '';
  for (const [label, fn] of buttons) { const b = document.createElement('button'); b.textContent = label; b.addEventListener('click', fn); box.appendChild(b); }
  $('notice').hidden = false;
}
const hideNotice = () => { $('notice').hidden = true; };

async function openBytes(data, name) {
  hideNotice();
  $('dropText').textContent = t('pdfLoading');
  try {
    const task = pdfjsLib.getDocument({
      data, cMapUrl: base + 'pdfjs/cmaps/', cMapPacked: true, standardFontDataUrl: base + 'pdfjs/standard_fonts/',
      wasmUrl: base + 'pdfjs/wasm/', iccUrl: base + 'pdfjs/iccs/', isEvalSupported: false
    });
    pdfDoc = await task.promise;
    linkService.setDocument(pdfDoc); pdfViewer.setDocument(pdfDoc);
    cmd('GR_DOC_CHANGED');                       // 換了文件：清掉舊文件的高光與閱讀位置（校準與模型不受影響，不需要重新校準）
    document.title = (name || 'PDF') + ' — ' + t('pdfViewerTitle');
    $('drop').classList.add('hide');
    refreshPage();
    // 掃描檔沒有文字層：高光無法定位，提醒使用者
    let chars = 0;
    for (let i = 1; i <= Math.min(3, pdfDoc.numPages); i++) {
      const tc = await (await pdfDoc.getPage(i)).getTextContent();
      chars += tc.items.reduce((a, it) => a + (it.str ? it.str.trim().length : 0), 0);
    }
    if (!chars) showNotice(t('pdfNoText'));
  } catch (e) {
    $('dropText').textContent = t('pdfDrop');
    showNotice(t('pdfError', { err: e && e.message ? e.message : e }));
  }
}

const nameOf = (u) => { try { return decodeURIComponent(new URL(u).pathname.split('/').pop()) || 'PDF'; } catch (_) { return 'PDF'; } };

async function openUrl(url) {
  $('dropText').textContent = t('pdfLoading');
  try {
    let buf;
    if (/^file:/i.test(url)) {
      // fetch() 不支援 file://；擴充功能在「允許存取檔案網址」開啟時，可以用 XMLHttpRequest 讀本機檔案
      buf = await new Promise((resolve, reject) => {
        const x = new XMLHttpRequest();
        x.open('GET', url); x.responseType = 'arraybuffer';
        x.onload = () => ((x.status === 200 || x.status === 0) && x.response && x.response.byteLength ? resolve(x.response) : reject(new Error('HTTP ' + x.status)));
        x.onerror = () => reject(new TypeError('Failed to read file'));
        x.send();
      });
    } else {
      const res = await fetch(url);
      if (!res.ok) throw new Error('HTTP ' + res.status);
      buf = await res.arrayBuffer();
    }
    await openBytes(new Uint8Array(buf), nameOf(url));
  } catch (e) {
    $('dropText').textContent = t('pdfDrop');
    const btns = [];
    if (/^file:/i.test(url)) {      // 本機檔案：沒開「允許存取檔案網址」就讀不到 → 教使用者用檔案選擇（不需要權限）或去開啟設定
      btns.push([t('btnOpenExtSettings'), () => chrome.tabs.create({ url: 'chrome://extensions/?id=' + chrome.runtime.id })]);
      btns.push([t('pdfOpen'), () => $('file').click()]);
      showNotice(t('fileAccessMsg'), btns);
    } else {                        // 一般網址：跨網域讀取需要授權
      btns.push([t('pdfGrant'), async () => {
        try { if (await chrome.permissions.request({ origins: [new URL(url).origin + '/*'] })) { hideNotice(); openUrl(url); } } catch (_) { /* ignore */ }
      }]);
      btns.push([t('pdfOpen'), () => $('file').click()]);
      showNotice(t('pdfNeedPerm') + ' (' + (e && e.message ? e.message : e) + ')', btns);
    }
  }
}

/* ── 開啟檔案：按鈕 / 拖曳 / ?file= ── */
$('bOpen').addEventListener('click', () => $('file').click());
$('file').addEventListener('change', async () => {
  const f = $('file').files[0];
  if (f) openBytes(new Uint8Array(await f.arrayBuffer()), f.name);
  $('file').value = '';
});
window.addEventListener('dragover', (e) => { e.preventDefault(); document.body.classList.add('dragging'); });
window.addEventListener('dragleave', (e) => { if (!e.relatedTarget) document.body.classList.remove('dragging'); });
window.addEventListener('drop', async (e) => {
  e.preventDefault(); document.body.classList.remove('dragging');
  const f = e.dataTransfer.files[0];
  if (f) openBytes(new Uint8Array(await f.arrayBuffer()), f.name);
});
$('bZoomIn').addEventListener('click', () => { pdfViewer.currentScale = Math.min(5, pdfViewer.currentScale * 1.15); });
$('bZoomOut').addEventListener('click', () => { pdfViewer.currentScale = Math.max(0.25, pdfViewer.currentScale / 1.15); });

/* ── 視線追蹤控制（與 content.js 同一個頁面，用自訂事件溝通）── */
const cmd = (type) => new Promise((res) => { window.dispatchEvent(new CustomEvent('gr-cmd', { detail: { type, respond: res } })); });
let grState = 'OFF';
async function refreshStatus() {
  const r = await cmd('GR_PING');
  grState = r ? r.state : 'OFF';
  const on = grState !== 'OFF';
  $('bStart').textContent = t(on ? 'pdfStop' : 'pdfStart');
  $('bCalib').disabled = !on;
  $('status').textContent = on ? (r.paused ? t('statusPaused') : t('statusOn', { state: grState })) : (r && r.lastError ? t('statusFailed', { err: r.lastError }) : '');
}
$('bStart').addEventListener('click', async () => { await cmd(grState === 'OFF' ? 'GR_START' : 'GR_STOP'); refreshStatus(); });
$('bCalib').addEventListener('click', async () => { await cmd('GR_CALIBRATE'); refreshStatus(); });
setInterval(refreshStatus, 800);

await loadLang();
const fileParam = new URL(location.href).searchParams.get('file');
if (fileParam) openUrl(fileParam);
