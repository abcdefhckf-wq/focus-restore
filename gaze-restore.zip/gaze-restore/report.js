/**
 * report.js — 把閱讀紀錄（chrome.storage 的 trials）整理成可以直接交給教授的 Excel 活頁簿
 * 工作表：摘要（整體統計＋分組統計）／中斷紀錄（中文欄位、秒）／設定與裝置／欄位說明
 * 中文介面（zh-TW、zh-CN）輸出繁體中文，其餘語言輸出英文。
 */
const GR_REPORT_TEXT = {
  zh: {
    file: '閱讀實驗資料', title: '視線中斷偵測與焦點還原 — 閱讀實驗資料',
    meta: (n, k, a, b, now) => `匯出時間 ${now}・共 ${n} 筆中斷紀錄・受試者 ${k} 位・資料期間 ${a} ～ ${b}`,
    sSummary: '摘要', sTrials: '中斷紀錄', sDevice: '設定與裝置', sCodebook: '欄位說明',
    overall: '整體統計', metric: '指標', value: '數值', note: '說明',
    m: [
      ['中斷次數', '偵測到的閱讀中斷總數（每筆＝一次離開又回來並按空白鍵）'],
      ['顯示高光的比例', '回來時成功在文章上顯示圓形高光的比例'],
      ['平均離開時間（秒）', '從判定中斷到偵測回到螢幕'],
      ['恢復閱讀時間：平均（秒）', '從回到螢幕到按空白鍵（找回閱讀位置）'],
      ['恢復閱讀時間：中位數（秒）', '較不受極端值影響'],
      ['恢復閱讀時間：標準差（秒）', '樣本標準差'],
      ['LLM 定位成功率', '有呼叫 LLM 的中斷中，成功回傳句子的比例'],
      ['LLM 平均回應時間（秒）', ''],
      ['回來後再次中斷（平均次數）', '高光出現後、按空白鍵前又離開的次數']
    ],
    bySubject: '依受試者', byReason: '依中斷原因', bySource: '依高光定位方式', byCond: '依實驗條件（距離 × 角度）',
    hSubject: ['受試者', '中斷次數', '顯示高光比例', '平均離開時間（秒）', '平均恢復時間（秒）', '中位數恢復時間（秒）'],
    hGroup: ['類別', '次數', '比例', '平均恢復時間（秒）'],
    hCond: ['距離（公分）', '角度', '次數', '平均恢復時間（秒）'],
    noSubject: '（未填）',
    reason: { BODY_MOTION: '頭部或身體轉動', EYES_AWAY: '只有眼睛轉走', EYES_CLOSED: '閉眼', GAZE_OUT_OF_BOUNDS: '視線離開螢幕', FACE_LOST: '臉離開鏡頭', TAB_HIDDEN: '切換分頁' },
    source: { llm: 'LLM 語意校準', local: '幾何定位（最近的句子）', gaze: '視線落點', none: '無法定位' },
    yes: '是', no: '否',
    trialCols: ['編號', '時間', '受試者', '距離（公分）', '角度', '中斷原因', '離開時間（秒）', '恢復閱讀時間（秒）', '顯示高光', '高光出現延遲（秒）', '高光定位方式', '還原的句子', 'LLM 成功', 'LLM 回應時間（秒）', 'LLM 信心', '再次中斷次數', '網頁'],
    devCols: ['編號', '時間', '受試者', '視線消失判定（秒）', '頭部角度閥值（°）', '視線偏離閥值（°）', '出界角度閥值（°）', '高光直徑（公分）', '高光透明度', '誤差修正模型', '幾何定位的句子', '視線 X（px）', '視線 Y（px）',
      '每秒張數', '鏡頭解析度', '鏡頭名稱', '雜訊（公分）', '校準誤差（公分）', 'CPU 核心數', '記憶體（GB）', '作業系統', '螢幕尺寸（吋）', '視窗寬（px）', '視窗高（px）', '縮放比例',
      '套用：移動判定（公分/秒）', '套用：取樣時間（毫秒）', '套用：找字半徑（公分）', '套用：出界角度（°）', 'LLM 錯誤訊息'],
    codebook: [
      ['中斷原因', '頭部或身體轉動／只有眼睛轉走／閉眼／視線離開螢幕／臉離開鏡頭／切換分頁，取最先達到門檻的訊號'],
      ['離開時間', '從判定中斷到偵測回到螢幕的時間（秒）'],
      ['恢復閱讀時間', '從偵測回到螢幕，到使用者按空白鍵（表示已找回閱讀位置）的時間（秒）；本研究的主要依變數'],
      ['顯示高光', '回來時是否在文章上顯示圓形高光'],
      ['高光出現延遲', '從偵測回到螢幕到高光出現的時間（秒），包含等待 LLM 回應'],
      ['高光定位方式', 'LLM 語意校準＝LLM 判斷的句子；幾何定位＝離視線最近的句子；視線落點＝直接用視線座標；無法定位＝沒有顯示高光'],
      ['還原的句子', '高光所標示的句子原文'],
      ['LLM 信心', 'LLM 自評的信心（0～1）'],
      ['再次中斷次數', '高光出現後、按空白鍵前又離開的次數'],
      ['距離／角度', '實驗條件（自變數）：眼睛到鏡頭的實測距離、使用者相對鏡頭的角度'],
      ['設定與裝置', '每筆紀錄當下的判定閥值、高光設定，以及筆電效能與鏡頭資訊，可作為共變數'],
      ['雜訊', '注視同一點時視線估計的散布：σ = 1.4826·√(MADx² + MADy²)，換算成公分'],
      ['校準誤差', '校準驗證的留一法平均誤差（公分）'],
      ['套用：…', '依該電腦量測到的雜訊、每秒張數與校準誤差自動調整後的實際判斷參數']
    ],
    cbField: '欄位', cbDesc: '說明'
  },
  en: {
    file: 'reading-data', title: 'Gaze Interruption Detection & Focus Restore — Reading Study Data',
    meta: (n, k, a, b, now) => `Exported ${now} · ${n} interruptions · ${k} participant(s) · ${a} to ${b}`,
    sSummary: 'Summary', sTrials: 'Interruptions', sDevice: 'Settings & device', sCodebook: 'Codebook',
    overall: 'Overall', metric: 'Measure', value: 'Value', note: 'Note',
    m: [
      ['Interruptions', 'Each record = one look-away, return and Space press'],
      ['Highlight shown', 'Share of returns where the circular highlight was shown'],
      ['Mean time away (s)', 'From interruption to detected return'],
      ['Recovery time: mean (s)', 'From return to Space press (place found)'],
      ['Recovery time: median (s)', 'Robust to outliers'],
      ['Recovery time: SD (s)', 'Sample standard deviation'],
      ['LLM success rate', 'Among interruptions that called the LLM'],
      ['Mean LLM latency (s)', ''],
      ['Re-interruptions (mean)', 'Look-aways after the highlight appeared, before Space']
    ],
    bySubject: 'By participant', byReason: 'By interruption cause', bySource: 'By highlight method', byCond: 'By condition (distance × angle)',
    hSubject: ['Participant', 'Interruptions', 'Highlight shown', 'Mean away (s)', 'Mean recovery (s)', 'Median recovery (s)'],
    hGroup: ['Category', 'Count', 'Share', 'Mean recovery (s)'],
    hCond: ['Distance (cm)', 'Angle', 'Count', 'Mean recovery (s)'],
    noSubject: '(blank)',
    reason: { BODY_MOTION: 'Head/body turned', EYES_AWAY: 'Eyes only turned away', EYES_CLOSED: 'Eyes closed', GAZE_OUT_OF_BOUNDS: 'Gaze off screen', FACE_LOST: 'Face left camera', TAB_HIDDEN: 'Tab switched' },
    source: { llm: 'LLM semantic', local: 'Geometric (nearest sentence)', gaze: 'Gaze point', none: 'Not located' },
    yes: 'Yes', no: 'No',
    trialCols: ['No.', 'Time', 'Participant', 'Distance (cm)', 'Angle', 'Cause', 'Time away (s)', 'Recovery time (s)', 'Highlight shown', 'Highlight delay (s)', 'Highlight method', 'Restored sentence', 'LLM ok', 'LLM latency (s)', 'LLM confidence', 'Re-interruptions', 'Page'],
    devCols: ['No.', 'Time', 'Participant', 'Face-lost limit (s)', 'Head angle threshold (°)', 'Gaze-away threshold (°)', 'Off-screen threshold (°)', 'Highlight diameter (cm)', 'Highlight opacity', 'Correction model', 'Geometric sentence', 'Gaze X (px)', 'Gaze Y (px)',
      'Frames/s', 'Camera resolution', 'Camera', 'Noise (cm)', 'Calibration error (cm)', 'CPU cores', 'Memory (GB)', 'OS', 'Screen (in)', 'Window W (px)', 'Window H (px)', 'Zoom',
      'Applied: move speed (cm/s)', 'Applied: window (ms)', 'Applied: anchor radius (cm)', 'Applied: off-screen (°)', 'LLM error'],
    codebook: [
      ['Cause', 'First signal to reach threshold: head/body turned, eyes only, eyes closed, gaze off screen, face left camera, tab switched'],
      ['Time away', 'Seconds from interruption to detected return'],
      ['Recovery time', 'Seconds from detected return to the Space press (place found); main dependent variable'],
      ['Highlight shown', 'Whether the circular highlight appeared on return'],
      ['Highlight delay', 'Seconds from return to highlight, including LLM wait'],
      ['Highlight method', 'LLM semantic / geometric nearest sentence / raw gaze point / not located (no highlight)'],
      ['Restored sentence', 'Text of the highlighted sentence'],
      ['LLM confidence', 'Self-reported confidence (0–1)'],
      ['Re-interruptions', 'Look-aways after the highlight appeared, before Space'],
      ['Distance / Angle', 'Independent variables: measured eye–camera distance and user angle'],
      ['Settings & device', 'Thresholds, highlight settings, laptop and camera info at the time of each record (covariates)'],
      ['Noise', 'Spread of gaze estimates while fixating: σ = 1.4826·√(MADx² + MADy²), in cm'],
      ['Calibration error', 'Leave-one-out mean validation error (cm)'],
      ['Applied: …', 'Detection parameters auto-adjusted from this laptop’s measured noise, frame rate and calibration error']
    ],
    cbField: 'Field', cbDesc: 'Description'
  }
};

function grBuildReport(trials, lang, angleName) {
  const L = GR_REPORT_TEXT[/^zh/.test(lang) ? 'zh' : 'en'], X = GR_XS;
  const num = (v) => (v === '' || v == null || !isFinite(Number(v))) ? null : Number(v);
  const sec = (ms) => { const n = num(ms); return n == null ? null : n / 1000; };
  const pad = (n) => String(n).padStart(2, '0');
  const fmtTime = (iso) => { const d = new Date(iso); return isNaN(d) ? (iso || '') : `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`; };
  const truthy = (v) => v === true || v === 'true' || v === 1 || v === '1';
  const mean = (a) => a.length ? a.reduce((s, x) => s + x, 0) / a.length : null;
  const median = (a) => { if (!a.length) return null; const b = [...a].sort((x, y) => x - y), m = b.length >> 1; return b.length % 2 ? b[m] : (b[m - 1] + b[m]) / 2; };
  const sd = (a) => { if (a.length < 2) return null; const m = mean(a); return Math.sqrt(a.reduce((s, x) => s + (x - m) ** 2, 0) / (a.length - 1)); };
  const vals = (rows, f) => rows.map(f).filter((v) => v != null);
  const subj = (r) => (r.subjectId || '').trim() || L.noSubject;
  const dec = (x) => { try { return decodeURIComponent(x); } catch (_) { return x; } };   // 網址裡的中文是 %E7%9C%BC… 編碼，解回原字
  const page = (u) => {
    try {
      const x = new URL(u);
      if (x.protocol === 'chrome-extension:') { const f = x.searchParams.get('file'); return 'PDF' + (f ? '：' + dec(f.split(/[\\/]/).pop()) : ''); }
      return x.hostname + dec(x.pathname);
    } catch (_) { return dec(u || ''); }
  };

  const rows = [...trials].sort((a, b) => String(a.time).localeCompare(String(b.time)));
  const rec = (r) => sec(r.recoveryMs);
  const usedLLM = (r) => (r.llmLatencyMs !== '' && r.llmLatencyMs != null) || !!r.llmError;

  /* ── 中斷紀錄 ── */
  const tRows = [L.trialCols.map((h) => ({ v: h, s: X.head }))];
  rows.forEach((r, i) => tRows.push([
    { v: i + 1, s: X.int }, { v: fmtTime(r.time) }, { v: subj(r) }, { v: num(r.distanceCm), s: X.int }, { v: angleName(r.userAngle) },
    { v: L.reason[r.interruptReason] || r.interruptReason || '' }, { v: sec(r.awayMs), s: X.num1 }, { v: rec(r), s: X.num2 },
    { v: truthy(r.highlightShown) ? L.yes : L.no }, { v: sec(r.highlightDelayMs), s: X.num2 }, { v: L.source[r.source] || r.source || '' },
    { v: r.sentence || '', s: X.wrap }, { v: usedLLM(r) ? (truthy(r.llmOk) ? L.yes : L.no) : '' },
    { v: sec(r.llmLatencyMs), s: X.num2 }, { v: num(r.llmConfidence), s: X.num2 }, { v: num(r.reinterrupts), s: X.int }, { v: page(r.url) }
  ]));

  /* ── 設定與裝置 ── */
  const dRows = [L.devCols.map((h) => ({ v: h, s: X.head }))];
  rows.forEach((r, i) => dRows.push([
    { v: i + 1, s: X.int }, { v: fmtTime(r.time) }, { v: subj(r) }, { v: num(r.lostSec), s: X.num1 }, { v: num(r.headAngleDeg), s: X.int }, { v: num(r.awayDeg), s: X.int },
    { v: num(r.angleDeg), s: X.int }, { v: num(r.circleCm), s: X.num1 }, { v: num(r.opacity), s: X.pct }, { v: r.corrType || '' }, { v: r.geometricSentence || '', s: X.wrap },
    { v: num(r.gazeX), s: X.int }, { v: num(r.gazeY), s: X.int }, { v: num(r.fps), s: X.int }, { v: r.camW ? `${r.camW}×${r.camH}` : '' }, { v: r.camLabel || '' },
    { v: num(r.noiseCm), s: X.num2 }, { v: num(r.calibErrCm), s: X.num2 }, { v: num(r.cpuCores), s: X.int }, { v: num(r.memGB), s: X.int }, { v: r.platform || '' },
    { v: num(r.screenDiagIn), s: X.num1 }, { v: num(r.screenW), s: X.int }, { v: num(r.screenH), s: X.int }, { v: num(r.dpr), s: X.num2 },
    { v: num(r.adMoveCmS), s: X.num1 }, { v: num(r.adWindowMs), s: X.int }, { v: num(r.adAnchorCm), s: X.num2 }, { v: num(r.adOutDeg), s: X.num2 }, { v: r.llmError || '' }
  ]));

  /* ── 摘要 ── */
  const llmRows = rows.filter(usedLLM);
  const recs = vals(rows, rec);
  const subjects = [...new Set(rows.map(subj))];
  const times = rows.map((r) => fmtTime(r.time).slice(0, 10)).filter(Boolean);
  const s = [];
  const merges = [];
  s.push([{ v: L.title, s: X.title }]); merges.push([0, 0, 0, 5]);
  s.push([{ v: L.meta(rows.length, subjects.length, times[0] || '-', times[times.length - 1] || '-', fmtTime(new Date().toISOString())), s: X.sub }]); merges.push([1, 0, 1, 5]);
  s.push([]);
  const section = (title) => { s.push([{ v: title, s: X.title }]); };
  section(L.overall);
  merges.push([s.length, 2, s.length, 5]);
  s.push([{ v: L.metric, s: X.head }, { v: L.value, s: X.head }, { v: L.note, s: X.head }, { s: X.head }, { s: X.head }, { s: X.head }]);
  const overall = [
    [rows.length, X.int], [rows.length ? rows.filter((r) => truthy(r.highlightShown)).length / rows.length : null, X.pct],
    [mean(vals(rows, (r) => sec(r.awayMs))), X.num1], [mean(recs), X.num2], [median(recs), X.num2], [sd(recs), X.num2],
    [llmRows.length ? llmRows.filter((r) => truthy(r.llmOk)).length / llmRows.length : null, X.pct],
    [mean(vals(llmRows, (r) => sec(r.llmLatencyMs))), X.num2], [mean(vals(rows, (r) => num(r.reinterrupts))), X.num2]
  ];
  L.m.forEach(([name, note], i) => { const r0 = s.length; s.push([{ v: name, s: X.label }, { v: overall[i][0] == null ? '—' : overall[i][0], s: overall[i][1] }, { v: note, s: X.wrap }]); merges.push([r0, 2, r0, 5]); });
  s.push([]);

  section(L.bySubject);
  s.push(L.hSubject.map((h) => ({ v: h, s: X.head })));
  for (const k of subjects) {
    const g = rows.filter((r) => subj(r) === k), gr = vals(g, rec);
    s.push([{ v: k, s: X.label }, { v: g.length, s: X.int }, { v: g.filter((r) => truthy(r.highlightShown)).length / g.length, s: X.pct },
      { v: mean(vals(g, (r) => sec(r.awayMs))), s: X.num1 }, { v: mean(gr), s: X.num2 }, { v: median(gr), s: X.num2 }]);
  }
  s.push([]);

  const groupTable = (title, keyFn, nameFn) => {
    section(title);
    s.push(L.hGroup.map((h) => ({ v: h, s: X.head })));
    const keys = [...new Set(rows.map(keyFn))];
    keys.sort((a, b) => rows.filter((r) => keyFn(r) === b).length - rows.filter((r) => keyFn(r) === a).length);
    for (const k of keys) {
      const g = rows.filter((r) => keyFn(r) === k);
      s.push([{ v: nameFn(k), s: X.label }, { v: g.length, s: X.int }, { v: g.length / rows.length, s: X.pct }, { v: mean(vals(g, rec)), s: X.num2 }]);
    }
    s.push([]);
  };
  groupTable(L.byReason, (r) => r.interruptReason || '', (k) => L.reason[k] || k || '—');
  groupTable(L.bySource, (r) => r.source || 'none', (k) => L.source[k] || k);

  section(L.byCond);
  s.push(L.hCond.map((h) => ({ v: h, s: X.head })));
  const conds = [...new Set(rows.map((r) => `${r.distanceCm}|${r.userAngle}`))].sort((a, b) => parseFloat(a) - parseFloat(b) || a.localeCompare(b));
  for (const c of conds) {
    const [d, a] = c.split('|'), g = rows.filter((r) => `${r.distanceCm}|${r.userAngle}` === c);
    s.push([{ v: num(d), s: X.int }, { v: angleName(a) }, { v: g.length, s: X.int }, { v: mean(vals(g, rec)), s: X.num2 }]);
  }

  const cb = [[L.cbField, L.cbDesc].map((h) => ({ v: h, s: X.head })), ...L.codebook.map(([a, b]) => [{ v: a, s: X.label }, { v: b, s: X.wrap }])];

  return {
    fileBase: L.file,
    sheets: [
      { name: L.sSummary, rows: s, cols: [30, 14, 22, 22, 22, 24], merges },
      { name: L.sTrials, rows: tRows, cols: [7, 20, 10, 14, 12, 18, 16, 20, 11, 20, 24, 60, 11, 20, 11, 14, 40], freeze: 1, filter: [0, L.trialCols.length] },
      { name: L.sDevice, rows: dRows, cols: [7, 20, 10, 20, 20, 20, 20, 18, 12, 16, 50, 12, 12, 10, 14, 26, 12, 14, 10, 12, 12, 12, 12, 12, 10, 28, 28, 28, 24, 30], freeze: 1, filter: [0, L.devCols.length] },
      { name: L.sCodebook, rows: cb, cols: [22, 90], freeze: 1 }
    ]
  };
}
