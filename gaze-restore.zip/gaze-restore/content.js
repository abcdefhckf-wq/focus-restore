/**
 * content.js — 隔離世界（Isolated World）
 *
 * 管線：WebGazer 原始視線 → 誤差修正（二次多項式）→ 1€ 平滑 → 速度閘 + 穩健重心
 *       → 離開訊號（視線出界 / 頭身軌跡 / 眼睛轉走 / 閉眼）→ 離開分數（遲滯）→ 中斷
 *       → 以「離開前最後的注視」鎖定閱讀位置 → LLM 語意校準 → 圓形高光（錨定在文字上）
 *       → 空白鍵（最高優先）3 秒漸淡
 *
 * ┌─ 狀態機 ───────────────────────────────────────────────────────────────┐
 * │ OFF ─start→ CALIBRATING ─完成→ READING ─中斷 True→ INTERRUPTED          │
 * │ INTERRUPTED ─回歸(True→False)→ RETURNED ─空白鍵→ READING                │
 * │ RETURNED 期間再次中斷 → 回 INTERRUPTED（沿用原本鎖定的焦點，不覆蓋）        │
 * │ 分頁切到背景（鎖定）：立即視為中斷並停鏡頭；回來 → 重啟鏡頭 → 回歸          │
 * └────────────────────────────────────────────────────────────────────────┘
 */
(() => {
  'use strict';
  if (window.__GR_CONTENT__) return;
  window.__GR_CONTENT__ = true;
  // 擴充功能重新載入後，舊的內容腳本會留在頁面上（在另一個隔離世界）並繼續收視線事件、各自畫高光 → 疊成兩層。
  //  ① 新實例啟動時廣播 gr-takeover，有這個機制的舊實例收到就停用；
  //  ② 沒有這個機制的更舊版本：它們畫的高光沒有我們的識別碼 → 一出現就移除。畫面上永遠只有目前這一份腳本的一顆。
  let dead = false;
  const INST = Math.random().toString(36).slice(2);
  window.dispatchEvent(new Event('gr-takeover'));
  const sweepForeign = () => document.querySelectorAll(`.gr-overlay:not([data-gr-inst="${INST}"]),.gr-offscreen:not([data-gr-inst="${INST}"])`).forEach((n) => n.remove());
  new MutationObserver(() => { if (!dead) sweepForeign(); }).observe(document.documentElement, { childList: true });
  window.addEventListener('gr-takeover', () => { dead = true; document.querySelectorAll('.gr-overlay,.gr-offscreen,.gr-calib-layer,.gr-acc-layer').forEach((n) => n.remove()); });

  /* ═════════════ 0. 常數 ═════════════ */
  const CFG = {
    // ── 離開／回歸判定（離開分數 + 遲滯）──
    AWAY_TAU: 350,              // 離開分數的時間常數（ms）：單一幀的誤判不會觸發，連續約 0.5 秒才會
    AWAY_HI: 0.75,              // 分數 ≥ 0.75 → 判定中斷
    AWAY_LO: 0.25,              // 分數 ≤ 0.25 且臉穩定在場 → 判定回歸（遲滯，避免來回抖動）
    RETURN_CONFIRM_MS: 400,     // 臉連續在場至少這麼久才可回歸
    WATCHDOG_MS: 200,
    TAU_EYES: 600,              // 只有眼睛轉走（頭不動）：約需連續 0.8 秒才中斷（原本 0.5 秒）；頭/身體轉走仍是 AWAY_TAU（0.5 秒）
    TAU_GAZE: 800,              // 只有視線估計出界/貼邊：約需連續 1.1 秒（原本 0.5 秒），飄一下不算
    SCROLL_GRACE_MS: 800,       // 捲動中與捲動後 0.8 秒：視線在邊緣不算出界（捲動時眼睛常看向捲軸/邊緣）
    GAZE_LAG_MS: 100,           // 攝影機視線估計約落後 100ms：換算成文件座標時用「100ms 前」的捲動量
    TURN_LOST_SEC: 0.8,         // 「快速轉頭」模式下，臉消失超過此秒數就判中斷（一般情況用使用者設定的 lostSec）
    PIN_MARGIN_PX: 10,          // 視線估計「貼在螢幕邊緣」也視為出界（webcam 估計常被夾在邊緣）
    EDGE_PX: 4,
    VIEW_DISTANCE_CM: 60,
    PITCH_DEG_PER_IDX: 90,      // 俯仰指數 → 角度的近似係數（粗略，建議實驗校正）
    EYE_FACTOR: 0.8,            // 虹膜位移比例 r = 0.8·sinθ（眼球半徑約 12mm、半眼寬約 15mm）→ θ = asin(r/0.8)
    CLOSED_RATIO: 0.45,         // 眼睛開闔度低於基準的 45% 視為閉眼/低頭
    CLOSED_MS: 900,
    BLINK_RATIO: 0.7,           // 眼睛開闔度低於基準的 70% → 這一幀視為「眨眼中」：眼睛特徵不可靠（虹膜亂跳、視線估計亂飄）
    BLINK_MAX_MS: 600,          // 開闔度持續偏低超過 0.6 秒就不是眨眼了（低頭看手機/鍵盤時眼皮會半閉）→ 恢復正常判斷
    BLINK_HOLD_MS: 160,         // 眨眼結束後再忽略 160ms（眼皮重新張開的過渡幀）；持續閉眼 ≥ CLOSED_MS 仍照樣判定為閉眼
    BODY_SHIFT_FW: 0.8,         // 臉中心平移超過 0.8 個臉寬視為身體移動
    SCALE_MIN: 0.6, SCALE_MAX: 1.6,
    BASELINE_ALPHA: 0.002,      // 姿態基準慢速自適應（約 15 秒），容許坐姿緩慢漂移
    BODY_STUCK_MS: 4000,        // 頭/眼偏離基準但視線在界內超過此時間 → 重建基準（避免卡住）
    ACTIVITY_RETURN_AFTER_MS: 1500, // 中斷 1.5 秒後，臉在場 + 有捲動/按鍵/點擊 → 也視為回歸（備援）

    // ── 閱讀位置（速度閘 + 遞減權重 + 離群剔除的穩健重心）──
    GZ_WINDOW_MS: 1800,         // 取離開前 1.8 秒的視線
    GZ_TAU_MS: 900,             // 權重 = exp(−距離離開時刻/0.9s)：越接近離開越重要
    GZ_MOVE_CM_S: 12,           // 速度 > 12 公分/秒的樣本視為掃視/漂移，不採用（100ms 窗口量測，雜訊約 3 公分/秒）
    GZ_MIN_N: 5,                // 非移動樣本少於 5 個才放寬
    GZ_R_CM: 2.0,               // 離群剔除半徑下限（公分）；實際取 max(2cm, 3×MAD)
    GZ_KEEP_MS: 4000,
    HIST_MAX_AGE_MS: 120000,

    // ── 校準 ──
    CLICKS: 3,                  // 9 點校準每點點 3 下
    BAR_SPEED: 0.16,            // 進度條前進速度（每秒佔全長比例）
    TRAIN_LAG_MS: 120,          // 眼睛追隨目標有約 120ms 延遲，訓練標籤取「120ms 前」的目標位置
    VAL_SETTLE: 600, VAL_COLLECT: 800,
    WEAK_CM: 2.2,               // 驗證誤差超過 2.2 公分的點，自動補強

    LLM_WAIT_MS: 2500,
    FADE_MS: 3000,
    BRIGHT_RATIO: 1.5,
    MARKER: '⟦GAZE⟧',
    CTX: { maxBlockChars: 1500, maxNeighborChars: 600, neighborBlocks: 2, maxHtmlChars: 3000, maxCandidates: 12 }
  };

  const BLOCK_TAGS = new Set(['P', 'LI', 'DIV', 'ARTICLE', 'SECTION', 'TD', 'TH', 'BLOCKQUOTE',
    'H1', 'H2', 'H3', 'H4', 'H5', 'H6', 'PRE', 'DD', 'DT', 'FIGCAPTION', 'MAIN']);
  const SKIP_TAGS = new Set(['SCRIPT', 'STYLE', 'NOSCRIPT', 'TEXTAREA', 'INPUT', 'SELECT', 'SVG', 'CANVAS']);
  const SENT_RE = /(?:[^。！？!?.\n]|\.(?!\s|$))+(?:[。！？!?]+|\.(?=\s|$))?["'”’」』)）]*/g;

  /* ═════════════ 1. 狀態 ═════════════ */
  const S = { ...GR_DEFAULTS };
  let state = 'OFF';              // OFF | CALIBRATING | READING | INTERRUPTED | RETURNED | TESTING
  let paused = false, pausedWhy = '', resuming = false, resumeAction = null;
  let lastFaceTs = 0, prevFaceT = 0, faceStreak = null;
  let awayScore = 0, lastScoreT = 0, cleanT = 0, lastAwayKind = '';
  let lastTurnMag = 0, closedSince = null, bodyStuckSince = null;
  let gazeDrift = false, driftInSince = null;
  let lastActivityTs = 0, lastScrollTs = 0, blinkUntil = 0, blinkStart = null;
  let returnSeq = 0, watchdog = null, blurTimer = null, lastError = '';
  let session = null, current = null, lastReading = null;
  let overlayRoot = null, spotEl = null, indicatorEl = null, rafId = null, lastCenter = null, spotD = 0;
  let accAbort = false, accSamples = [], accCollecting = false;
  let calibSink = null;           // 校準期間接收「原始視線」的回呼
  const calibState = { token: null };
  const rawRecent = [];           // 校準期間最近的原始視線（供進度條「看著目標才前進」的判斷）
  const poseBase = { samples: [], ready: false, v: null };
  const gz = [];                  // 閱讀中的視線樣本 {dx,dy,t,mov}（文件座標，不受捲動影響）
  let corrState = null;           // 誤差修正模型 { model, W, H, ... }
  let modelSnapshot = null, pendingModelCb = null, pendingImport = null, autosaveTimer = null;   // 校準檔（WebGazer 訓練資料）的保存與還原

  const median = (arr) => { const s = arr.slice().sort((a, b) => a - b); return s[s.length >> 1]; };
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));

  /* ── 裝置品質（自動量測）與自適應參數 ──
   * 每台筆電的鏡頭、效能、螢幕不同，視線估計的「雜訊」與「誤差」也不同。程式自動量測：
   *   fps      實際每秒收到幾張視線估計（反映電腦效能＋鏡頭）
   *   noisePx  雜訊：校準驗證時盯著同一點，原始估計的散布 σ = 1.4826·√(MADx² + MADy²)
   *   errPx    誤差：校準後（留一法）估計與目標的平均距離
   * 再用公式把判斷參數調到適合這台電腦（沒有量測值時＝原本的固定值，行為與原版相同）：
   *   移動判定速度  v = clamp(0.7·σ(cm)·fps, 12, 40) 公分/秒   雜訊大或 fps 高時，雜訊本身就會造成「看起來在動」，門檻要跟著提高，否則樣本全被當成掃視丟掉
   *   取樣時間窗    W = clamp(1.8 s × max(1, 15/fps), 1.8, 3.0) 秒  fps 低時拉長，確保離開前有足夠樣本
   *   找字半徑      r = clamp(1.5·err, max(60px, 1.2cm), 3cm)       校準誤差大時，視線落點離真正的字比較遠
   *   出界角度      θ = 設定值 + min(3°, atan(σ/距離))              雜訊大時多留餘裕，避免雜訊造成「出界」誤判
   */
  const devQ = { fps: 0, camW: 0, camH: 0, camFps: 0, camLabel: '', noisePx: null, errPx: null };
  let fpsDt = 0, lastEvtT = 0, adCache = null, adT = 0;
  function adapt() {
    const nowT = performance.now();
    if (adCache && nowT - adT < 1000) return adCache;
    const ppc = pxPerCm(), fps = devQ.fps || 30, dist = S.distanceCm || CFG.VIEW_DISTANCE_CM;
    const sigCm = devQ.noisePx != null ? devQ.noisePx / ppc : 0;     // 還沒量到：不加任何調整（＝原本的固定值）
    const errPx = devQ.errPx != null ? devQ.errPx : 0;
    adCache = {
      moveCmS: clamp(0.7 * sigCm * fps, CFG.GZ_MOVE_CM_S, 40),
      windowMs: clamp(CFG.GZ_WINDOW_MS * Math.max(1, 15 / fps), CFG.GZ_WINDOW_MS, 3000),
      anchorPx: clamp(1.5 * errPx, Math.max(60, 1.2 * ppc), 3 * ppc),
      outDeg: S.angleDeg > 0 ? S.angleDeg + Math.min(3, Math.atan(sigCm / dist) * 180 / Math.PI) : 0
    };
    adT = nowT;
    return adCache;
  }
  /** 實驗資料裡一起記錄的裝置資訊（分析時可以看出差異來自筆電還是自變數） */
  function devRec() {
    const ppc = pxPerCm(), a = adapt(), ua = navigator.userAgentData;
    return {
      fps: devQ.fps ? Math.round(devQ.fps) : '', camW: devQ.camW || '', camH: devQ.camH || '', camFps: devQ.camFps || '', camLabel: devQ.camLabel || '',
      noiseCm: devQ.noisePx != null ? +(devQ.noisePx / ppc).toFixed(2) : '', calibErrCm: devQ.errPx != null ? +(devQ.errPx / ppc).toFixed(2) : '',
      cpuCores: navigator.hardwareConcurrency || '', memGB: navigator.deviceMemory || '', platform: (ua && ua.platform) || navigator.platform || '',
      screenDiagIn: S.screenDiagIn, dpr: devicePixelRatio, screenW: innerWidth, screenH: innerHeight,
      adMoveCmS: +a.moveCmS.toFixed(1), adWindowMs: Math.round(a.windowMs), adAnchorCm: +(a.anchorPx / ppc).toFixed(2), adOutDeg: +a.outDeg.toFixed(2)
    };
  }
  const asinDeg = (r) => Math.asin(clamp(r, -1, 1)) * 180 / Math.PI;
  const pxPerCm = () => Math.hypot(screen.width, screen.height) / ((S.screenDiagIn || 14) * 2.54);
  /** 捲動量 = 視窗捲動 + 主要捲動容器（PDF 閱讀器在容器內捲動，視窗本身不動） */
  const sX = () => window.scrollX + (window.__GR_SCROLLER ? window.__GR_SCROLLER.scrollLeft : 0);
  const sY = () => window.scrollY + (window.__GR_SCROLLER ? window.__GR_SCROLLER.scrollTop : 0);
  const isPdfMode = () => !!window.__GR_PDF;
  const scrollHist = [];          // 最近 1.5 秒的捲動位置 {t,x,y}：視線估計有延遲，換算文件座標要用「當時」的捲動量
  function scrollAt(t) {
    let r = null;
    for (let i = scrollHist.length - 1; i >= 0; i--) if (scrollHist[i].t <= t) { r = scrollHist[i]; break; }
    r = r || scrollHist[0];
    return r ? { x: r.x, y: r.y } : { x: sX(), y: sY() };
  }
  /** 校準檔以「螢幕 + 距離 + 角度」為單位：不同實驗條件各自一份；同一台電腦、同樣姿勢，換網頁/換 PDF/重開瀏覽器都沿用 */
  const profileSuffix = () => `|d${S.distanceCm}|${S.angleLabel}`;
  const physW = () => Math.round(innerWidth * devicePixelRatio), physH = () => Math.round(innerHeight * devicePixelRatio);   // 視窗的「實體像素」大小：不受網頁縮放影響
  const profileKey = () => `v2|${Math.round(physW() / 50) * 50}x${Math.round(physH() / 50) * 50}${profileSuffix()}`;
  /** 找最適合目前條件的校準檔：同距離、同角度、實體視窗大小差 ≤ 8%（網頁縮放不同也算同一份）；多份符合時取大小最接近、最新的 */
  function findProfile(profiles) {
    let best = null;
    for (const [k, p] of Object.entries(profiles || {})) {
      if (!p || !p.model || !p.model.fx || p.model.fx.length < 20 || !k.endsWith(profileSuffix())) continue;
      const pw = p.PW || Math.round(p.W * devicePixelRatio), ph = p.PH || Math.round(p.H * devicePixelRatio);   // 舊格式沒存實體大小：假設縮放相同
      const dw = Math.abs(pw - physW()) / physW(), dh = Math.abs(ph - physH()) / physH();
      if (dw > 0.08 || dh > 0.08) continue;
      const score = dw + dh;
      if (!best || score < best.score - 1e-9 || (Math.abs(score - best.score) < 1e-9 && p.ts > best.p.ts)) best = { k, p, score };
    }
    return best;
  }

  chrome.storage.local.get(GR_DEFAULTS).then(async (v) => {
    Object.assign(S, v); delete S.llmApiKey;
    await grLoadLang(S.language);
  });
  chrome.storage.onChanged.addListener((ch) => {
    for (const k in ch) if (k in S) S[k] = ch[k].newValue;
    if (ch.language) grLoadLang(S.language);
  });

  /* ═════════════ 2. 平滑（1€ Filter）═════════════
   *  為什麼用 1€？它依「視線移動速度」動態調整截止頻率：
   *   注視時速度低 → 截止頻率低 → 強力抑制無意識的微跳動（microsaccade、webcam 雜訊）；
   *   掃視時速度高 → 截止頻率升高 → 幾乎沒有延遲。
   *  公式：α = 1 / (1 + τ/Δt)，τ = 1/(2π·fc)，fc = fmin + β·|dx/dt|（濾波後的速度）
   */
  function makeOneEuro(minCut, beta, dCut) {
    let t0 = null, xp = 0, dxp = 0;
    const alpha = (fc, dt) => 1 / (1 + (1 / (2 * Math.PI * fc)) / dt);
    return {
      reset() { t0 = null; },
      f(x, t) {
        if (t0 === null || t - t0 > 400) { t0 = t; xp = x; dxp = 0; return x; }
        const dt = Math.max(0.001, (t - t0) / 1000); t0 = t;
        dxp += alpha(dCut, dt) * ((x - xp) / dt - dxp);
        xp += alpha(minCut + beta * Math.abs(dxp), dt) * (x - xp);
        return xp;
      }
    };
  }
  const smoothX = makeOneEuro(1.0, 0.01, 1.0), smoothY = makeOneEuro(1.0, 0.01, 1.0);
  const resetSmooth = () => { smoothX.reset(); smoothY.reset(); };

  /* ═════════════ 3. 誤差修正（校準驗證後擬合）═════════════
   *  WebGazer 的 ridge 回歸在螢幕邊緣（尤其下方）常有系統性偏差。校準後我們用 12 個已知點
   *  量測「原始估計 → 真實位置」的殘差，擬合二次多項式修正：
   *     u = x/W, v = y/H;  φ = [1, u, v, u², v², uv]
   *     (x', y') = (x, y) + (W·φ·wx, H·φ·wy)         （修正量以殘差回歸，ridge 讓資料不足時退回「不修正」）
   *  以「留一法」(leave-one-target-out) 比較「不修正 / 仿射 / 二次」，只有確實更準才採用；修正量上限 25% 螢幕。
   */
  const feat = (type, u, v) => (type === 'quad' ? [1, u, v, u * u, v * v, u * v] : [1, u, v]);

  function solve(A, b) {                       // 高斯消去（k ≤ 6）
    const n = b.length, M = A.map((r, i) => [...r, b[i]]);
    for (let c = 0; c < n; c++) {
      let p = c; for (let r = c + 1; r < n; r++) if (Math.abs(M[r][c]) > Math.abs(M[p][c])) p = r;
      [M[c], M[p]] = [M[p], M[c]];
      const d = M[c][c] || 1e-9;
      for (let j = c; j <= n; j++) M[c][j] /= d;
      for (let r = 0; r < n; r++) if (r !== c) { const f = M[r][c]; for (let j = c; j <= n; j++) M[r][j] -= f * M[c][j]; }
    }
    return M.map((r) => r[n]);
  }

  function fitResidual(type, pts, W, H, lambda) {
    const k = feat(type, 0, 0).length;
    const A = Array.from({ length: k }, () => Array(k).fill(0)), bx = Array(k).fill(0), by = Array(k).fill(0);
    for (const p of pts) {
      const f = feat(type, p.rx / W, p.ry / H), ex = (p.tx - p.rx) / W, ey = (p.ty - p.ry) / H;
      for (let i = 0; i < k; i++) { for (let j = 0; j < k; j++) A[i][j] += f[i] * f[j]; bx[i] += f[i] * ex; by[i] += f[i] * ey; }
    }
    for (let i = 1; i < k; i++) A[i][i] += lambda;
    return { type, wx: solve(A, bx), wy: solve(A, by), W, H };
  }

  function predict(m, rx, ry) {
    if (!m) return { x: rx, y: ry };
    const f = feat(m.type, rx / m.W, ry / m.H);
    let ex = 0, ey = 0;
    for (let i = 0; i < f.length; i++) { ex += f[i] * m.wx[i]; ey += f[i] * m.wy[i]; }
    return { x: rx + clamp(ex, -0.25, 0.25) * m.W, y: ry + clamp(ey, -0.25, 0.25) * m.H };
  }

  /** rows: [{tx,ty,rx,ry}]；回傳 { model, rawPx, fitPx(留一法), perTarget:[{err}] } */
  function fitCorrection(rows) {
    const W = innerWidth, H = innerHeight, pts = rows.filter((r) => r.rx != null);
    const raw = pts.map((p) => Math.hypot(p.rx - p.tx, p.ry - p.ty));
    const mean = (a) => a.length ? a.reduce((x, y) => x + y, 0) / a.length : 0;
    const out = { model: null, type: 'none', rawPx: mean(raw), fitPx: mean(raw), perTarget: rows.map(() => null) };
    const idxOf = new Map(pts.map((p, i) => [p, i]));
    const rawErr = (p) => Math.hypot(p.rx - p.tx, p.ry - p.ty);
    rows.forEach((r, i) => { if (r.rx != null) out.perTarget[i] = rawErr(r); });
    for (const [type, need] of [['affine', 5], ['quad', 9]]) {
      if (pts.length < need) continue;
      const errs = pts.map((p) => {
        const m = fitResidual(type, pts.filter((q) => q !== p), W, H, 0.03), q = predict(m, p.rx, p.ry);
        return Math.hypot(q.x - p.tx, q.y - p.ty);
      });
      if (mean(errs) < Math.min(out.fitPx, out.rawPx) * 0.92) {
        out.type = type; out.fitPx = mean(errs); out.model = fitResidual(type, pts, W, H, 0.03);
        rows.forEach((r, i) => { if (r.rx != null) out.perTarget[i] = errs[idxOf.get(r)]; });
      }
    }
    return out;
  }

  function applyCorrection(x, y) {
    const c = corrState;
    if (!c || !c.model || Math.abs(c.W - innerWidth) > 30 || Math.abs(c.H - innerHeight) > 30) return { x, y };
    return predict(c.model, x, y);
  }

  /* ═════════════ 4. 訊息 ═════════════ */
  function handleMsg(msg, send) {
    if (dead) return;
    switch (msg && msg.type) {
      case 'GR_PING': send({ ok: true, state, paused, lastError, pdf: isPdfMode() }); break;
      case 'GR_START': start(); send({ ok: true }); break;
      case 'GR_STOP': stop(); send({ ok: true }); break;
      case 'GR_CALIBRATE': if (state !== 'OFF' && !paused && state !== 'TESTING') startCalibration(); send({ ok: true }); break;
      case 'GR_ACCURACY': startAccuracyTest(); send({ ok: true }); break;
      case 'GR_DOC_CHANGED': onDocChanged(); send({ ok: true }); break;
    }
  }

  /** PDF 閱讀器換了一份文件：舊文件的高光、閱讀位置、視線樣本都作廢；校準與模型完全不受影響 */
  function onDocChanged() {
    returnSeq++; clearOverlay(); session = null; current = null; lastReading = null;
    gz.length = 0; awayScore = 0; faceStreak = null; resetSmooth();
    if (state === 'INTERRUPTED' || state === 'RETURNED') state = 'READING';
  }

  chrome.runtime.onMessage.addListener((msg, _s, send) => { handleMsg(msg, send); });
  // PDF 閱讀器是外掛自己的頁面：工具列用頁面內的自訂事件直接控制（同一個 JS 世界，不需要經過訊息通道）
  window.addEventListener('gr-cmd', (e) => { const m = e.detail || {}; handleMsg(m, m.respond || (() => {})); });

  const sendCmd = (cmd, extra = {}) => window.postMessage({ __gr: 'cmd', cmd, ...extra }, '*');
  const faceMeshPath = () => chrome.runtime.getURL('lib/mediapipe/face_mesh');
  const train = (x, y) => sendCmd('train', { x: Math.round(x), y: Math.round(y) });

  window.addEventListener('message', (e) => {
    if (dead || e.source !== window || !e.data || e.data.__gr !== 'evt') return;
    const d = e.data;
    if (d.type === 'gaze') onGaze(d);
    else if (d.type === 'ready') onBridgeReady();
    else if (d.type === 'model') {
      const cb = pendingModelCb; pendingModelCb = null;
      if (d.model && d.model.fx && d.model.fx.length) modelSnapshot = d.model;
      if (cb) cb(d.model);
    } else if (d.type === 'cam') { devQ.camW = d.w || 0; devQ.camH = d.h || 0; devQ.camFps = d.fps ? Math.round(d.fps) : 0; devQ.camLabel = String(d.label || '').slice(0, 60); }
    else if (d.type === 'modelLoaded') { const r = pendingImport; pendingImport = null; if (r) r(d.n); }
    else if (d.type === 'error') {
      const m = d.code ? t('err_' + d.code) : d.message;
      lastError = m; stop(true); toast(t('toastError', { err: m }), 8000);
    }
  });

  async function onBridgeReady() {
    if (resuming) {              // 鎖定後恢復：鏡頭重啟，確保模型還在
      resuming = false;
      sendCmd('preview', { on: false });
      if (modelSnapshot) sendCmd('importModel', { model: modelSnapshot });
      lastFaceTs = performance.now(); faceStreak = null; resetSmooth();
      if (resumeAction === 'calibrate') { resumeAction = null; startCalibration(); }
      else toast(t('toastResumed'));
      return;
    }
    // 先找有沒有這台電腦、這個條件的校準檔：有就直接用，不需要重新校準
    const loaded = await tryLoadProfile();
    if (state !== 'CALIBRATING') return;            // 等待期間使用者已經按了停止
    if (loaded) {
      sendCmd('preview', { on: false });
      state = 'READING'; lastFaceTs = performance.now(); faceStreak = null; awayScore = 0; gazeDrift = false;
      resetPoseBaseline(); resetSmooth(); gz.length = 0;
      toast(t('calibLoaded'), 6000);
      return;
    }
    toast(t('toastReady'));
    startCalibration();
  }

  /* ═════════ 校準檔：保存與還原 ═════════
   *  為什麼需要？WebGazer 只在「滑鼠點擊」時才會自己存訓練資料；我們的校準（進度條、驗證）是程式直接餵訓練點，
   *  所以它的資料從來沒被存下來。每次開新分頁（例如換一份 PDF）模型都是空的，但「誤差修正」卻還在 → 兩者對不上 → 抓不到位置。
   *  現在把「訓練資料 + 誤差修正」當成一份校準檔一起存、一起還原；兩者永遠成對，不會只剩一半。
   */
  function requestModel(cb) {
    pendingModelCb = cb; sendCmd('exportModel');
    setTimeout(() => { if (pendingModelCb === cb) { pendingModelCb = null; cb(null); } }, 1500);
  }
  function saveProfileNow() { requestModel((m) => { if (m) saveProfile(m); }); }

  async function saveProfile(model) {
    if (!model || !model.fx || model.fx.length < 20) return;     // 資料太少不存（避免用空模型覆蓋一份好的校準檔）
    modelSnapshot = model;
    try {
      const { profiles = {} } = await chrome.storage.local.get({ profiles: {} });
      const old = findProfile(profiles);                       // 已有同條件的校準檔 → 覆蓋它，不重複存
      profiles[old ? old.k : profileKey()] = { W: innerWidth, H: innerHeight, PW: physW(), PH: physH(), dpr: devicePixelRatio, ts: Date.now(), model, corr: corrState, noisePx: devQ.noisePx, errPx: devQ.errPx };
      const keep = Object.entries(profiles).sort((p, q) => q[1].ts - p[1].ts).slice(0, 8);   // 最多保留 8 份
      await chrome.storage.local.set({ profiles: Object.fromEntries(keep) });
    } catch (e) { console.warn('[GR] 儲存校準檔失敗', e); }
  }

  async function tryLoadProfile() {
    try {
      const { profiles = {} } = await chrome.storage.local.get({ profiles: {} });
      const hit = findProfile(profiles);
      if (!hit) return false;                                   // 沒有同條件的校準檔（距離/角度/視窗大小差太多）→ 才需要重新校準
      const p = hit.p;
      // 網頁縮放（例如 PDF 閱讀器放大）不同：同一個實體位置，CSS 像素座標會按比例改變 → 訓練標籤同比例換算
      const f = (p.dpr || devicePixelRatio) / devicePixelRatio;
      const sc = (v) => (Array.isArray(v) ? v.map((e) => e * f) : v * f);
      const model = Math.abs(f - 1) < 1e-6 ? p.model : { ...p.model, x: p.model.x.map(sc), y: p.model.y.map(sc) };
      const n = await new Promise((res) => {
        pendingImport = res; sendCmd('importModel', { model });
        setTimeout(() => { if (pendingImport === res) { pendingImport = null; res(0); } }, 3000);
      });
      if (n < 20) return false;
      // 誤差修正以「螢幕比例」(x/W, y/H) 為單位，改成目前視窗大小；否則視窗大小差 30px 以上時修正會被默默關掉
      corrState = p.corr && p.corr.model ? { ...p.corr, W: innerWidth, H: innerHeight, model: { ...p.corr.model, W: innerWidth, H: innerHeight } } : null;
      modelSnapshot = model;
      if (p.noisePx != null) devQ.noisePx = p.noisePx * f;
      if (p.errPx != null) devQ.errPx = p.errPx * f;
      adCache = null;
      return true;
    } catch (_) { return false; }
  }

  function start() {
    if (state !== 'OFF') return;
    lastError = ''; paused = false; resuming = false;
    state = 'CALIBRATING';
    toast(t('toastStarting'), 4000);
    sendCmd('start', { faceMeshPath: faceMeshPath() });
    watchdog = setInterval(onWatchdog, CFG.WATCHDOG_MS);
    autosaveTimer = setInterval(() => { if (state === 'READING' && !paused) saveProfileNow(); }, 60000);   // 閱讀中持續學習的成果也定期存
  }

  function stop(quiet) {
    abortCalibration();
    if (state === 'READING' || state === 'INTERRUPTED' || state === 'RETURNED') saveProfileNow();   // 停止前先存校準檔（匯出指令會排在停止指令之前）
    sendCmd('stop');
    clearInterval(watchdog); clearInterval(autosaveTimer); clearTimeout(blurTimer);
    clearOverlay();
    document.querySelectorAll('.gr-acc-layer').forEach((n) => n.remove());
    session = null; state = 'OFF'; paused = false; resuming = false; gazeDrift = false;
    awayScore = 0; gz.length = 0; lastReading = null; resetPoseBaseline(); resetSmooth();
    if (!quiet) toast(t('toastStopped'));
  }

  /* ═════════════ 5. 鎖定：分頁切走就停止鏡頭，回來再恢復 ═════════════ */
  document.addEventListener('visibilitychange', () => {
    if (state === 'OFF') return;
    if (document.hidden) lockPause('hidden'); else if (paused) lockResume();
  });
  window.addEventListener('blur', () => {
    if (!S.lockOnBlur || state === 'OFF') return;
    clearTimeout(blurTimer);
    blurTimer = setTimeout(() => { if (!document.hasFocus()) lockPause('blur'); }, 1500);
  });
  window.addEventListener('focus', () => { clearTimeout(blurTimer); if (paused && pausedWhy === 'blur') lockResume(); });

  function lockPause(why) {
    if (state === 'OFF' || paused) return;
    paused = true; pausedWhy = why;
    if (state === 'CALIBRATING') { abortCalibration(); resumeAction = 'calibrate'; }
    else if (state === 'TESTING') accAbort = true;
    else if (state === 'READING' || state === 'RETURNED') interrupt('TAB_HIDDEN', performance.now());
    saveProfileNow();
    sendCmd('stop');
  }
  function lockResume() {
    if (!paused) return;
    paused = false; resuming = true;
    toast(t('toastStarting'), 3000);
    sendCmd('start', { faceMeshPath: faceMeshPath() });
  }

  /* ═════════════ 6. 離開訊號與中斷判定（論文重點）═════════════
   *  每個有臉的取樣，計算四種「離開」訊號，任一成立 → 該取樣記為 away=1：
   *   S1 視線出界（動作軌跡）：視線座標超出視窗且視角 ≥ 閥值；或「貼在螢幕邊緣」（被夾在邊界）
   *   S2 頭/身體軌跡（動作軌跡）：頭左右/俯仰超過角度閥值、臉平移 > 0.8 臉寬、臉寬縮放超出 0.6~1.6 倍
   *   S3 眼睛轉走（新）：眼睛相對頭部的方向（虹膜位置）+ 頭部轉向合成後的「視線方向」偏離基準超過閥值
   *        → 偵測「身體不動、只有眼睛看向別處」，不依賴 webcam 視線估計（它在這種情況下常常還落在螢幕內）
   *   S4 閉眼/低頭（新）：眼睛開闔度低於基準 45% 持續 0.9 秒
   *  離開分數 s（遲滯）：s ← s + (away − s)·(1 − e^(−Δt/τ))，τ = 350ms
   *   s ≥ 0.75 → 中斷；回歸需 s ≤ 0.25 且臉連續在場 ≥ 0.4 秒。單一幀的誤判不會觸發，也不會因抖動來回切換。
   *  視線消失（條件 B）：臉連續偵測不到 ≥ lostSec（預設 2 秒）；若消失前正在「快速轉頭」，縮短為 0.8 秒。
   *  離開時刻 = 離開分數「最後一次 ≤ 0.1」的時間（真正的離開起點，而不是判定成立的時間）。
   *  防卡住備援：基準慢速自適應；頭/眼偏離但視線在界內 >4 秒 → 重建基準；中斷 1.5 秒後臉在場 + 捲動/按鍵/點擊 → 視為回歸。
   * ═══════════════════════════════════════════════════════════════ */
  function outsideAngleDeg(x, y) {
    const w = innerWidth, h = innerHeight, e = CFG.EDGE_PX;
    const dx = Math.max(0, e - x, x - (w - e)), dy = Math.max(0, e - y, y - (h - e));
    const px = Math.hypot(dx, dy);
    return px === 0 ? 0 : Math.atan(px / pxPerCm() / (S.distanceCm || CFG.VIEW_DISTANCE_CM)) * 180 / Math.PI;
  }
  const pinnedEdge = (x, y) => x <= CFG.PIN_MARGIN_PX || y <= CFG.PIN_MARGIN_PX || x >= innerWidth - CFG.PIN_MARGIN_PX || y >= innerHeight - CFG.PIN_MARGIN_PX;

  /** 合成視線方向的偏離閥值：不得小於「閱讀整個螢幕所需的視角」× 1.25 + 5°（近距離螢幕張角大，不能誤判） */
  function awayLimits() {
    const dist = S.distanceCm || CFG.VIEW_DISTANCE_CM, ppc = pxPerCm();
    const half = (px) => Math.atan((px / ppc / 2) / dist) * 180 / Math.PI;
    return [Math.max(S.awayDeg, half(screen.width) * 1.25 + 5), Math.max(S.awayDeg, half(screen.height) * 1.25 + 5)];
  }

  ['wheel', 'keydown', 'pointerdown', 'touchstart'].forEach((ev) =>
    window.addEventListener(ev, () => { lastActivityTs = performance.now(); }, { capture: true, passive: true }));
  let mouseWanted = false, mouseSuspended = false, mouseResumeTimer = null;
  const mouseSet = (on) => { mouseWanted = on; sendCmd('mouseTrain', { on: on && !mouseSuspended }); };
  window.addEventListener('scroll', () => {
    lastActivityTs = lastScrollTs = performance.now();
    // 捲動（尤其拖曳捲軸）時滑鼠停在捲軸/邊緣，眼睛卻在看文字：這時候的「滑鼠 = 視線」標籤是錯的，會把模型拉偏 → 捲動中暫停滑鼠學習
    if (mouseWanted && !mouseSuspended) { mouseSuspended = true; sendCmd('mouseTrain', { on: false }); }
    clearTimeout(mouseResumeTimer);
    mouseResumeTimer = setTimeout(() => { mouseSuspended = false; if (mouseWanted) sendCmd('mouseTrain', { on: true }); }, CFG.SCROLL_GRACE_MS);
  }, { capture: true, passive: true });

  /* ── 姿態基準 ── */
  const BASE_KEYS = ['yawIdx', 'pitchIdx', 'cx', 'cy', 'faceW', 'eyeX', 'eyeY', 'open'];
  function updatePoseBaseline(p) {
    if (!p || poseBase.ready) return;
    poseBase.samples.push(p);
    if (poseBase.samples.length >= 25) {
      const v = {};
      for (const k of BASE_KEYS) { const a = poseBase.samples.map((s) => s[k]).filter((x) => x != null); v[k] = a.length ? median(a) : null; }
      poseBase.v = v; poseBase.ready = true;
    }
  }
  function adaptBaseline(p) {
    if (!poseBase.ready || !p) return;
    for (const k of BASE_KEYS) if (poseBase.v[k] != null && p[k] != null) poseBase.v[k] += (p[k] - poseBase.v[k]) * CFG.BASELINE_ALPHA;
  }
  function resetPoseBaseline() { poseBase.samples = []; poseBase.ready = false; poseBase.v = null; closedSince = null; }

  function poseDev(p) {
    const b = poseBase.v;
    if (!p || !b) return null;
    const dev = {
      yaw: asinDeg(p.yawIdx - b.yawIdx), pitch: (p.pitchIdx - b.pitchIdx) * CFG.PITCH_DEG_PER_IDX,
      dx: (p.cx - b.cx) / b.faceW, dy: (p.cy - b.cy) / b.faceW, scale: p.faceW / b.faceW,
      eyeH: null, eyeV: null, openRatio: null
    };
    if (p.eyeX != null && b.eyeX != null) {
      dev.eyeH = asinDeg((p.eyeX - b.eyeX) / CFG.EYE_FACTOR);
      dev.eyeV = asinDeg((p.eyeY - b.eyeY) / CFG.EYE_FACTOR);
      dev.openRatio = b.open > 0 ? p.open / b.open : 1;
    }
    return dev;
  }

  function awaySignals(x, y, pose, now) {
    const ang = outsideAngleDeg(x, y);
    const angOut = ang > 0 && ang >= adapt().outDeg;
    const gazeOutRaw = angOut || pinnedEdge(x, y);
    if (gazeDrift) {   // 備援回歸時視線估計仍在界外（WebGazer 漂移）→ 先忽略 S1，視線回到界內 1 秒才恢復
      if (!gazeOutRaw) { if (driftInSince === null) driftInSince = now; if (now - driftInSince > 1000) gazeDrift = false; }
      else driftInSince = null;
    }
    const scrolling = now - lastScrollTs < CFG.SCROLL_GRACE_MS;
    // PDF 整頁都是文字，讀到最上/最下緣很正常，而 WebGazer 的估計會被夾在視窗邊緣 → PDF 不採用「貼邊」，只看真正出界（頭/眼/臉的訊號照常）
    const gazeOut = gazeOutRaw && !gazeDrift && !scrolling && !(isPdfMode() && !angOut);
    let body = false, eyes = false, closed = false;
    const dev = poseDev(pose);
    if (dev) {
      const T = S.headAngleDeg;
      lastTurnMag = Math.max(Math.abs(dev.yaw) / T, Math.abs(dev.dx) / CFG.BODY_SHIFT_FW);
      body = Math.abs(dev.yaw) > T || Math.abs(dev.pitch) > T || Math.abs(dev.dx) > CFG.BODY_SHIFT_FW ||
             Math.abs(dev.dy) > CFG.BODY_SHIFT_FW || dev.scale < CFG.SCALE_MIN || dev.scale > CFG.SCALE_MAX;
      if (dev.eyeH != null) {
        const [Tx, Ty] = awayLimits();
        eyes = Math.abs(dev.yaw + dev.eyeH) > Tx || (Math.abs(dev.eyeV) + 0.5 * Math.abs(dev.pitch)) > Ty;
        if (dev.openRatio < CFG.CLOSED_RATIO) { if (closedSince === null) closedSince = now; closed = now - closedSince >= CFG.CLOSED_MS; }
        else closedSince = null;
      }
    }
    const kind = body ? 'BODY_MOTION' : eyes ? 'EYES_AWAY' : closed ? 'EYES_CLOSED' : gazeOut ? 'GAZE_OUT_OF_BOUNDS' : '';
    return { away: !!kind, kind, gazeOutRaw, headEye: body || eyes };
  }

  function onGaze(d) {
    if (dead || state === 'OFF' || paused) return;
    const now = d.t;
    if (lastEvtT) { const dt = now - lastEvtT; if (dt > 0 && dt < 1000) { fpsDt = fpsDt ? fpsDt * 0.97 + dt * 0.03 : dt; devQ.fps = 1000 / fpsDt; } }
    lastEvtT = now;
    if (d.face) lastFaceTs = now;

    if (state === 'CALIBRATING') {            // 校準：收「原始」視線
      if (d.face) { rawRecent.push({ x: d.x, y: d.y, t: now }); while (rawRecent.length > 8) rawRecent.shift(); }
      if (calibSink) calibSink(d);
      return;
    }

    // 0) 眨眼過濾：眨眼時眼睛特徵不可靠，視線估計會亂飄、虹膜位置亂跳 → 這些幀不判離開、不進平滑、不當閱讀位置樣本。
    //    只有「持續閉眼 ≥ 0.9 秒」才算閉眼（照原本的規則）；單純眨眼不會觸發中斷，也不會污染離開前的位置。
    if (d.face) {
      const dv = poseDev(d.pose);
      if (dv && dv.openRatio != null) {
        if (dv.openRatio < CFG.CLOSED_RATIO) { if (closedSince === null) closedSince = now; } else closedSince = null;
        if (dv.openRatio < CFG.BLINK_RATIO) { if (blinkStart === null) blinkStart = now; blinkUntil = now + CFG.BLINK_HOLD_MS; }
        else if (now >= blinkUntil) blinkStart = null;
      }
      const longClosed = closedSince !== null && now - closedSince >= CFG.CLOSED_MS;
      // 頭部姿態（臉輪廓）不受眼皮影響：頭/身體已明顯轉走（低頭、轉頭、後仰）時不當成眨眼，照常判斷
      const T = S.headAngleDeg, bodyAway = !!dv && (Math.abs(dv.yaw) > T || Math.abs(dv.pitch) > T || Math.abs(dv.dx) > CFG.BODY_SHIFT_FW ||
        Math.abs(dv.dy) > CFG.BODY_SHIFT_FW || dv.scale < CFG.SCALE_MIN || dv.scale > CFG.SCALE_MAX);
      if (now < blinkUntil && !longClosed && !bodyAway && blinkStart !== null && now - blinkStart < CFG.BLINK_MAX_MS) { lastScoreT = now; return; }
    }

    scrollHist.push({ t: now, x: sX(), y: sY() }); while (scrollHist.length && now - scrollHist[0].t > 1500) scrollHist.shift();

    // 1) 誤差修正 → 平滑（之後所有判斷都用這個「最終視線」）
    let x = d.x, y = d.y;
    if (d.face) { const c = applyCorrection(x, y); x = smoothX.f(c.x, now); y = smoothY.f(c.y, now); }

    if (state === 'TESTING') { if (accCollecting) accSamples.push({ x, y, rx: d.x, ry: d.y, face: d.face }); return; }

    if (!d.face) { faceStreak = null; return; }
    if (faceStreak === null || now - prevFaceT > 250) faceStreak = now;
    prevFaceT = now;

    // 2) 離開訊號 → 離開分數
    const sig = awaySignals(x, y, d.pose, now);
    if ((state === 'READING' || state === 'RETURNED') && !sig.away) {      // RETURNED 也收樣本：高光出現後使用者讀到哪，再次中斷時才知道
      if (state === 'READING') { updatePoseBaseline(d.pose); adaptBaseline(d.pose); }
      const sc = scrollAt(now - CFG.GAZE_LAG_MS);
      feedGaze({ dx: x + sc.x, dy: y + sc.y, t: now, scr: now - lastScrollTs < 300 });
    }
    const dt = clamp(now - lastScoreT, 1, 150); lastScoreT = now;
    // 離開訊號越「強」累積越快：頭/身體轉走、閉眼 = AWAY_TAU；只有眼睛轉走 = TAU_EYES；只有視線估計出界 = TAU_GAZE（飄一下視線不會觸發）
    const tau = !sig.away ? CFG.AWAY_TAU
      : sig.kind === 'EYES_AWAY' ? CFG.TAU_EYES
      : sig.kind === 'GAZE_OUT_OF_BOUNDS' ? CFG.TAU_GAZE
      : CFG.AWAY_TAU;
    awayScore += ((sig.away ? 1 : 0) - awayScore) * (1 - Math.exp(-dt / tau));
    if (awayScore <= 0.1) cleanT = now;
    if (sig.away) lastAwayKind = sig.kind;
    if ((state === 'READING' || state === 'RETURNED') && awayScore >= CFG.AWAY_HI) interrupt(lastAwayKind || 'GAZE_OUT_OF_BOUNDS', cleanT);

    // 3) 回歸
    if (state === 'INTERRUPTED' && session) {
      const calm = awayScore <= CFG.AWAY_LO;
      const activeBack = now - lastActivityTs < 800 && now - session.interruptedAt > CFG.ACTIVITY_RETURN_AFTER_MS;
      if (now - faceStreak >= CFG.RETURN_CONFIRM_MS && (calm || activeBack)) {
        if (!calm) {                                   // 備援回歸：當下仍被判離開 → 判斷是哪一種「卡住」
          if (sig.gazeOutRaw) { gazeDrift = true; driftInSince = null; toast(t('toastDrift'), 5000); }
          else resetPoseBaseline();
        }
        awayScore = 0; bodyStuckSince = null; resetSmooth(); gz.length = 0;
        onReturn();
      } else if (!calm && !activeBack && sig.headEye && !sig.gazeOutRaw) {
        if (bodyStuckSince === null) bodyStuckSince = now;
        if (now - bodyStuckSince > CFG.BODY_STUCK_MS) { resetPoseBaseline(); bodyStuckSince = null; }   // 坐姿改變 → 重建基準
      } else bodyStuckSince = null;
    }
  }

  function onWatchdog() {
    if (dead || paused || resuming) return;
    // 孤兒高光保險：除了「等待空白鍵」之外的任何狀態，高光都不該停留 → 自動漸淡（不必重啟程式）
    if (state !== 'RETURNED' && (overlayRoot || document.querySelector('.gr-overlay:not(.gr-fading)'))) fadeOverlay();
    if (state !== 'READING' && state !== 'RETURNED') return;
    const lim = lastTurnMag > 0.5 ? Math.min(S.lostSec, CFG.TURN_LOST_SEC) : S.lostSec;   // 快速轉頭 → 縮短
    if (performance.now() - lastFaceTs >= lim * 1000) interrupt('FACE_LOST', lastFaceTs);
  }

  /* ═════════════ 7. 閱讀位置：速度閘 + 遞減權重 + 離群剔除的穩健重心 ═════════════
   *  人眼有無意識的微跳動（microsaccade）與 webcam 雜訊（實測約 ±30px），單點座標不能代表「正在讀哪裡」。
   *  做法（離開時刻 T 之前 1.8 秒的樣本）：
   *   1) 速度閘：100ms 內位移 / 時間 > 12 公分/秒 → 掃視或漂向別處，不採用（離開前眼睛先飄走的點就是這樣被排除）
   *   2) 權重 w = exp(−(T − t)/0.9s)：越接近離開的越重要，所以「剛回來只讀了 0.4 秒又離開」會取新位置而非舊位置
   *   3) 穩健重心：以加權中位數為起點，剔除距離 > max(2cm, 3×MAD) 的離群點，迭代 3 次取加權平均
   *   4) 若該重心不在文字上，再試第二個群集
   *  不需要等「注視結算」：快速轉頭時最後一個注視常常來不及結算，這個方法直接用原始樣本，沒有這個問題。
   * ═══════════════════════════════════════════════════════════════ */
  function feedGaze(s) {
    const n = gz.length, p = n >= 3 ? gz[n - 3] : null;
    s.mov = false;
    if (p && s.t - p.t > 0 && s.t - p.t <= 200) s.mov = Math.hypot(s.dx - p.dx, s.dy - p.dy) / ((s.t - p.t) / 1000) > adapt().moveCmS * pxPerCm();
    gz.push(s);
    while (gz.length && s.t - gz[0].t > CFG.GZ_KEEP_MS) gz.shift();
  }

  function wmedian(vals, ws) {
    const idx = vals.map((_, i) => i).sort((a, b) => vals[a] - vals[b]);
    const half = ws.reduce((a, b) => a + b, 0) / 2;
    let acc = 0;
    for (const i of idx) { acc += ws[i]; if (acc >= half) return vals[i]; }
    return vals[idx[idx.length - 1]];
  }

  function readingPosition(depT) {
    const lo = depT - adapt().windowMs, hi = depT + 150;
    let pool = gz.filter((s) => !s.mov && s.t >= lo && s.t <= hi);
    if (pool.length < CFG.GZ_MIN_N) pool = gz.filter((s) => s.t >= lo && s.t <= hi);
    const w = (s) => Math.exp(-Math.max(0, depT - s.t) / CFG.GZ_TAU_MS) * (s.scr ? 0.5 : 1);   // 捲動中的樣本可信度較低
    for (let attempt = 0; attempt < 2 && pool.length >= 3; attempt++) {
      let cx = wmedian(pool.map((s) => s.dx), pool.map(w)), cy = wmedian(pool.map((s) => s.dy), pool.map(w));
      const mad = (k, c) => median(pool.map((s) => Math.abs(s[k] - c)));
      const R = Math.max(CFG.GZ_R_CM * pxPerCm(), 3 * Math.hypot(mad('dx', cx), mad('dy', cy)));
      let sel = pool;
      for (let it = 0; it < 3; it++) {
        sel = pool.filter((s) => Math.hypot(s.dx - cx, s.dy - cy) <= R);
        if (sel.length < 3) break;
        let sw = 0, sx = 0, sy = 0;
        for (const s of sel) { const ww = w(s); sw += ww; sx += s.dx * ww; sy += s.dy * ww; }
        cx = sx / sw; cy = sy / sw;
      }
      if (sel.length >= 3) {
        const hit = findTextAnchor(cx - sX(), cy - sY()) || findTextAnchorNear(cx - sX(), cy - sY());   // 文件座標 → 現在的視窗座標；找不到就由內而外擴大搜尋（PDF 邊界/欄間空白）
        if (hit) return { docX: cx, docY: cy, n: sel.length, hit };
      }
      pool = pool.filter((s) => Math.hypot(s.dx - cx, s.dy - cy) > R);   // 第一個群集不在文字上 → 試第二個群集
    }
    return null;
  }

  function pickAnchor(depT) {
    const rp = readingPosition(depT);
    if (rp) { rp.at = performance.now(); lastReading = rp; return rp; }
    if (lastReading && lastReading.hit.node.isConnected && performance.now() - (lastReading.at || 0) < 20000) return { ...lastReading, n: 0 };   // 沒有新資料：只在「20 秒內」沿用上一次的閱讀位置（太久以前的位置不再可信）
    return null;
  }

  function interrupt(reason, departureT) {
    if (state === 'RETURNED' && session) {
      returnSeq++; clearOverlay();
      session.reinterrupts++;
      state = 'INTERRUPTED'; awayScore = Math.max(awayScore, 0.9); faceStreak = null;
      // 高光出現後使用者又讀了一段才離開 → 用「這段新的閱讀」重新定位；以前一律沿用第一次的位置，所以高光一直跳回第一次的地方
      const a = readingPosition(departureT);
      if (a && a.n >= CFG.GZ_MIN_N) {
        let ctx = null;
        try { ctx = buildContext(a); } catch (e) { console.warn('[GR] buildContext 失敗', e); }
        if (ctx) {
          a.at = performance.now(); lastReading = a; session.anchor = a; session.ctx = ctx; session.llm = null; session.sentence = null; session.source = 'none';
          session.llmPromise = S.useLLM ? askLLM(ctx.payload) : Promise.resolve(null);
        }
      }
      gz.length = 0;
      return;
    }
    if (state !== 'READING') return;
    state = 'INTERRUPTED'; awayScore = Math.max(awayScore, 0.9); faceStreak = null; bodyStuckSince = null;

    const anchor = pickAnchor(departureT);
    let ctx = null;
    try { ctx = anchor ? buildContext(anchor) : null; } catch (e) { console.warn('[GR] buildContext 失敗', e); }

    session = {
      reason, anchor, ctx, reinterrupts: 0, interruptedAt: performance.now(),
      llmPromise: (ctx && S.useLLM) ? askLLM(ctx.payload) : Promise.resolve(null),
      returnTs: null, shownTs: null, source: 'none', sentence: null
    };
    gz.length = 0;
  }

  /* ═════════════ 8. LLM 語意校準輸入打包 ═════════════ */
  function buildContext(anchor) {
    const x = anchor.docX - sX(), y = anchor.docY - sY();
    const hit = (anchor.hit && anchor.hit.node && anchor.hit.node.isConnected) ? anchor.hit : findTextAnchor(x, y);
    if (!hit) return null;

    const block = closestBlock(hit.node);
    const pdf = isPdfMode();
    const nb = pdf ? { before: [], after: [], ref: block } : neighborBlocks(block);   // PDF：不取前後頁（頁面文字層太大且與視線無關）
    const refEl = nb.ref || block;
    const scopeEls = [...nb.before, refEl, ...nb.after];

    const flat = flattenText(block);
    const entry = flat.nodes.find((n) => n.node === hit.node);
    const caretOff = entry ? entry.start + Math.min(hit.offset, entry.end - entry.start) : 0;
    const marked = windowAround(flat.text.slice(0, caretOff) + CFG.MARKER + flat.text.slice(caretOff), caretOff, CFG.CTX.maxBlockChars);

    let cands = [];
    for (const el of scopeEls) {
      const f = flattenText(el);
      for (const s of splitSentences(f.text)) {
        const r = makeRange(f, s.start, s.end);
        const dist = r ? distToRects(r.getClientRects(), x, y) : Infinity;
        if (isFinite(dist)) cands.push({ text: s.text.slice(0, 300), distancePx: Math.round(dist), inTargetBlock: el === refEl });
      }
    }
    if (cands.length > CFG.CTX.maxCandidates) {
      const keep = new Set(cands.slice().sort((a, b) => a.distancePx - b.distancePx).slice(0, CFG.CTX.maxCandidates));
      cands = cands.filter((c) => keep.has(c));
    }
    cands.forEach((c, i) => { c.id = i; });
    if (!cands.length) return null;

    const local = cands.slice().sort((a, b) => a.distancePx - b.distancePx || (b.inTargetBlock - a.inTargetBlock))[0];
    const clean = (el, mark) => {
      const c = el.cloneNode(true);
      c.querySelectorAll('script,style,svg,noscript,iframe,video,canvas,.gr-root').forEach((n) => n.remove());
      c.querySelectorAll('[style]').forEach((n) => n.removeAttribute('style'));
      if (mark) c.setAttribute('data-gr-gaze', '1');
      return c.outerHTML;
    };
    const htmlSnippet = pdf ? '' : scopeEls.map((el) => clean(el, el === refEl)).join('\n').slice(0, CFG.CTX.maxHtmlChars);
    const txt = (el) => (el.innerText || el.textContent || '').trim().slice(0, CFG.CTX.maxNeighborChars);

    return {
      anchor, client: { x, y }, scopeEls, block, localSentence: local.text,
      payload: {
        page: { url: location.href, title: document.title, lang: document.documentElement.lang || '' },
        gaze: { x: Math.round(x), y: Math.round(y), viewport: { w: innerWidth, h: innerHeight }, probeOffsetPx: hit.probeDy || 0, sampleCount: anchor.n },
        markedText: marked,
        neighbors: { before: nb.before.map(txt), after: nb.after.map(txt) },
        candidates: cands, htmlSnippet
      }
    };
  }

  function findTextAnchor(x, y) {
    const maxD = adapt().anchorPx;
    for (const dy of [0, 12, -12, 24, -24, 40, -40]) {
      for (const dx of [0, -80, 80]) {
        const c = caretAt(x + dx, y + dy);
        if (!c || !c.node || c.node.nodeType !== 3 || !c.node.nodeValue.trim()) continue;
        const p = c.node.parentElement;
        if (!p || SKIP_TAGS.has(p.tagName.toUpperCase()) || p.closest('.gr-root')) continue;
        const r = document.createRange(); r.selectNodeContents(c.node);
        if (distToRects(r.getClientRects(), x, y) > maxD) continue;
        return { node: c.node, offset: c.offset, probeDy: dy };
      }
    }
    return null;
  }

  /** 視線落在大片空白（PDF 邊界、欄間）時：由內而外一圈圈找最近的正文，最遠 6 公分 */
  function findTextAnchorNear(x, y) {
    const R = 6 * pxPerCm();
    for (let r = 40; r <= R; r += 40) {
      let best = null;
      const n = Math.max(8, Math.round(r / 12));
      for (let k = 0; k < n; k++) {
        const a = (2 * Math.PI * k) / n, px = x + r * Math.cos(a), py = y + r * Math.sin(a);
        const c = caretAt(px, py);
        if (!c || !c.node || c.node.nodeType !== 3 || !c.node.nodeValue.trim()) continue;
        const p = c.node.parentElement;
        if (!p || SKIP_TAGS.has(p.tagName.toUpperCase()) || p.closest('.gr-root')) continue;
        const rg = document.createRange(); rg.selectNodeContents(c.node);
        const d = distToRects(rg.getClientRects(), x, y);
        if (d <= r + 60 && (!best || d < best.d)) best = { node: c.node, offset: c.offset, d };
      }
      if (best) return { node: best.node, offset: best.offset, probeDy: 0 };
    }
    return null;
  }

  function caretAt(x, y) {
    if (document.caretPositionFromPoint) {
      const p = document.caretPositionFromPoint(x, y);
      return p ? { node: p.offsetNode, offset: p.offset } : null;
    }
    const r = document.caretRangeFromPoint && document.caretRangeFromPoint(x, y);
    return r ? { node: r.startContainer, offset: r.startOffset } : null;
  }

  function closestBlock(node) {
    const tl = (node.nodeType === 1 ? node : node.parentElement) && (node.nodeType === 1 ? node : node.parentElement).closest('.textLayer');
    if (tl) return tl;                       // PDF：整頁的文字層就是一個區塊
    let el = node.nodeType === 1 ? node : node.parentElement, best = null;
    while (el && el !== document.body && el !== document.documentElement) {
      if (BLOCK_TAGS.has(el.tagName)) {
        const len = (el.textContent || '').trim().length;
        if (len > 6000) break;
        if (len >= 30) { best = el; if (len >= 80) break; }
      }
      el = el.parentElement;
    }
    return best || node.parentElement;
  }

  const usableBlock = (el) => !SKIP_TAGS.has(el.tagName.toUpperCase()) && !el.closest('.gr-root') && (el.textContent || '').trim().length >= 10;

  function neighborBlocks(block) {
    let ref = block, parent = block.parentElement;
    while (parent && parent !== document.body && [...parent.children].filter(usableBlock).length < 3) { ref = parent; parent = parent.parentElement; }
    if (!parent) return { before: [], after: [], ref: block };
    const sibs = [...parent.children].filter((el) => el === ref || usableBlock(el));
    const i = sibs.indexOf(ref), N = CFG.CTX.neighborBlocks;
    return { before: sibs.slice(Math.max(0, i - N), i), after: sibs.slice(i + 1, i + 1 + N), ref };
  }

  async function askLLM(payload) {
    const t0 = performance.now();
    try {
      const r = await chrome.runtime.sendMessage({ type: 'GR_LLM_CALIBRATE', payload });
      return { ...(r || { ok: false }), rttMs: Math.round(performance.now() - t0) };
    } catch (e) { return { ok: false, error: String(e), rttMs: Math.round(performance.now() - t0) }; }
  }

  /* ═════════════ 9. 文字 ↔ Range 工具 ═════════════ */
  function flattenText(root) {
    const nodes = []; let text = '', prev = null;
    const pdf = isPdfMode();
    const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode(n) {
        const p = n.parentElement;
        return (!p || SKIP_TAGS.has(p.tagName.toUpperCase()) || p.closest('.gr-root')) ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT;
      }
    });
    let n;
    while ((n = w.nextNode())) {
      if (pdf && prev && n.parentElement !== prev) text += ' ';   // PDF 文字層每段文字是獨立的 <span>，補一個空白避免黏在一起
      prev = n.parentElement;
      const v = n.nodeValue; nodes.push({ node: n, start: text.length, end: text.length + v.length }); text += v;
    }
    return { text, nodes };
  }
  function offsetToPoint(flat, off, isEnd) {
    for (const n of flat.nodes) if (isEnd ? (off > n.start && off <= n.end) : (off >= n.start && off < n.end)) return { node: n.node, offset: off - n.start };
    const l = flat.nodes[flat.nodes.length - 1];
    return l ? { node: l.node, offset: l.end - l.start } : null;
  }
  function makeRange(flat, s, e) {
    const a = offsetToPoint(flat, s, false), b = offsetToPoint(flat, e, true);
    if (!a || !b) return null;
    const r = document.createRange();
    try { r.setStart(a.node, a.offset); r.setEnd(b.node, b.offset); } catch (_) { return null; }
    return r;
  }
  function splitSentences(text) {
    const out = []; let m;
    SENT_RE.lastIndex = 0;
    while ((m = SENT_RE.exec(text))) {
      const lead = m[0].length - m[0].trimStart().length, tt = m[0].trim();
      if (tt.length >= 4) out.push({ start: m.index + lead, end: m.index + lead + tt.length, text: tt });
    }
    return out;
  }
  const escapeRe = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const windowAround = (s, idx, max) => { if (s.length <= max) return s; const a = Math.max(0, idx - (max >> 1)); return s.slice(a, a + max); };
  function distToRects(rects, x, y) {
    let best = Infinity;
    for (const r of rects) best = Math.min(best, Math.hypot(Math.max(r.left - x, 0, x - r.right), Math.max(r.top - y, 0, y - r.bottom)));
    return best;
  }

  function locateSentence(sentence, scopeEls) {
    const s = (sentence || '').trim();
    if (s.length < 2) return null;
    const exact = new RegExp(escapeRe(s).replace(/\s+/g, '\\s+'));
    const compact = s.replace(/\s+/g, '');
    const search = (el) => {
      const flat = flattenText(el), m = exact.exec(flat.text);
      if (m) return { range: makeRange(flat, m.index, m.index + m[0].length), block: el };
      let c = '', map = [];
      for (let i = 0; i < flat.text.length; i++) if (!/\s/.test(flat.text[i])) { c += flat.text[i]; map.push(i); }
      const k = c.indexOf(compact);
      if (k >= 0) return { range: makeRange(flat, map[k], map[k + compact.length - 1] + 1), block: el };
      return null;
    };
    for (const el of scopeEls || []) { if (!el.isConnected) continue; const r = search(el); if (r && r.range) return r; }
    return search(document.body);
  }

  function snapToRange(range, gx, gy) {
    const rects = [...range.getClientRects()].filter((r) => r.width > 0 && r.height > 0);
    const fallback = { node: range.startContainer, offset: range.startOffset };
    if (!rects.length) return fallback;
    let best = null, bd = Infinity;
    for (const r of rects) {
      const d = Math.hypot(Math.max(r.left - gx, 0, gx - r.right), Math.max(r.top - gy, 0, gy - r.bottom));
      if (d < bd) { bd = d; best = r; }
    }
    const c = caretAt(Math.min(Math.max(gx, best.left + 1), best.right - 1), (best.top + best.bottom) / 2);
    if (c && c.node && c.node.nodeType === 3) { try { if (range.isPointInRange(c.node, c.offset)) return { node: c.node, offset: c.offset }; } catch (_) { /* ignore */ } }
    return fallback;
  }

  /* ═════════════ 10. 回歸 → 圓形高光（錨定在文字上，跟著文字移動）═════════════ */
  async function onReturn() {
    if (state !== 'INTERRUPTED' || !session) return;
    state = 'RETURNED';
    const seq = ++returnSeq;
    session.returnTs = performance.now();

    let llm = null;
    if (session.llmPromise) llm = await Promise.race([session.llmPromise, sleep(CFG.LLM_WAIT_MS).then(() => null)]);
    if (seq !== returnSeq || state !== 'RETURNED') return;
    session.llm = llm;

    const ctx = session.ctx, an = session.anchor;
    const gx = an ? an.docX - sX() : 0, gy = an ? an.docY - sY() : 0;
    let pos = null, hit = null;
    if (ctx) {
      if (llm && llm.ok && llm.sentence) { hit = locateSentence(llm.sentence, ctx.scopeEls); if (hit) { session.source = 'llm'; session.sentence = llm.sentence; } }
      if (!hit && ctx.localSentence) { hit = locateSentence(ctx.localSentence, ctx.scopeEls); if (hit) { session.source = 'local'; session.sentence = ctx.localSentence; } }
      if (hit && hit.range) pos = { ...snapToRange(hit.range, gx, gy), sentence: session.sentence, scopeEls: ctx.scopeEls };
    }
    if (!pos && an && an.hit && an.hit.node.isConnected) { pos = { node: an.hit.node, offset: an.hit.offset, sentence: null, scopeEls: [] }; session.source = 'gaze'; }
    if (!pos) { toast(t('toastNoLocate')); return; }

    current = pos;
    renderSpot();
    revealIfOffscreen();
    session.shownTs = performance.now();
  }

  function renderSpot() {
    clearOverlay(true);
    document.querySelectorAll('.gr-overlay,.gr-offscreen').forEach((n) => n.remove());     // 保證畫面上只會有一層高光（含任何殘留的孤兒）
    spotD = Math.max(40, (S.circleCm || 4) * pxPerCm());
    const A = clamp(S.opacity, 0.05, 1);
    const root = document.createElement('div');
    root.className = 'gr-root gr-overlay gr-enter'; root.dataset.grInst = INST;
    root.style.setProperty('--gr-rgb', hexToRgb(S.color));
    root.style.setProperty('--gr-a-core', A);
    root.style.setProperty('--gr-a-ring', A / CFG.BRIGHT_RATIO);
    root.style.setProperty('--gr-fade-ms', CFG.FADE_MS + 'ms');
    const spot = document.createElement('div');
    spot.className = 'gr-spot';
    spot.style.width = spot.style.height = spotD + 'px';
    root.appendChild(spot);
    const ind = document.createElement('button');
    ind.type = 'button'; ind.className = 'gr-root gr-offscreen'; ind.hidden = true; ind.dataset.grInst = INST;
    ind.addEventListener('click', () => { if (current && current.node.parentElement) current.node.parentElement.scrollIntoView({ block: 'center', behavior: 'smooth' }); });
    document.documentElement.appendChild(root);
    document.documentElement.appendChild(ind);
    overlayRoot = root; spotEl = spot; indicatorEl = ind; lastCenter = null;
    rafId = requestAnimationFrame(followFrame);
  }

  function charCenter() {
    const c = current;
    if (!c) return null;
    if (!c.node.isConnected) relocate();
    if (!c.node.isConnected) return null;
    const len = c.node.nodeValue.length;
    if (!len) return null;
    const off = Math.min(c.offset, len - 1), r = document.createRange();
    try { r.setStart(c.node, off); r.setEnd(c.node, off + 1); } catch (_) { return null; }
    const rs = r.getClientRects(), b = rs.length ? rs[0] : r.getBoundingClientRect();
    if (!b || (!b.width && !b.height)) return null;
    return { x: b.left + b.width / 2, y: b.top + b.height / 2 };
  }

  let lastRelocate = 0;
  function relocate() {
    const now = performance.now();
    if (!current || !current.sentence || now - lastRelocate < 500) return;
    lastRelocate = now;
    const hit = locateSentence(current.sentence, current.scopeEls);
    if (hit && hit.range) {
      const p = lastCenter ? snapToRange(hit.range, lastCenter.x, lastCenter.y) : { node: hit.range.startContainer, offset: hit.range.startOffset };
      current.node = p.node; current.offset = p.offset;
    }
  }

  function followFrame() {
    rafId = null;
    if (!overlayRoot || !spotEl) return;
    const c = charCenter();
    if (c) {
      lastCenter = c;
      spotEl.style.transform = `translate3d(${c.x - spotD / 2}px,${c.y - spotD / 2}px,0)`;
      spotEl.style.visibility = 'visible';
      if (indicatorEl) {
        const off = c.y < 0 ? 'up' : (c.y > innerHeight ? 'down' : '');
        indicatorEl.hidden = !off || overlayRoot.classList.contains('gr-fading');
        if (off) { indicatorEl.textContent = t(off === 'up' ? 'offUp' : 'offDown'); indicatorEl.className = 'gr-root gr-offscreen gr-' + off; }
      }
    } else if (!overlayRoot.classList.contains('gr-fading')) spotEl.style.visibility = 'hidden';
    rafId = requestAnimationFrame(followFrame);
  }

  function revealIfOffscreen() {
    const c = charCenter();
    if (!c) return;
    if ((c.y < 0 || c.y > innerHeight) && performance.now() - lastScrollTs > 1500 && current.node.parentElement) {
      current.node.parentElement.scrollIntoView({ block: 'center', behavior: 'smooth' });
    }
  }

  const hexToRgb = (h) => {
    const m = /^#?([0-9a-f]{6})$/i.exec(h || '') || /^#?([0-9a-f]{6})$/i.exec(GR_DEFAULTS.color);
    const n = parseInt(m[1], 16);
    return `${(n >> 16) & 255} ${(n >> 8) & 255} ${n & 255}`;
  };

  function clearOverlay(keepCurrent) {
    if (rafId) { cancelAnimationFrame(rafId); rafId = null; }
    if (overlayRoot) { overlayRoot.remove(); overlayRoot = null; }
    if (indicatorEl) { indicatorEl.remove(); indicatorEl = null; }
    spotEl = null;
    if (!keepCurrent) current = null;
  }

  /** 3 秒漸淡（動態衰減）；漸淡期間仍保留錨點，圓才會「淡出」而不是瞬間消失 */
  function fadeOverlay() {
    let did = false;
    const root = overlayRoot;
    if (root && !root.classList.contains('gr-fading')) {
      root.classList.add('gr-fading');
      if (indicatorEl) indicatorEl.hidden = true;
      setTimeout(() => { if (overlayRoot === root) clearOverlay(); else root.remove(); }, CFG.FADE_MS + 60);
      did = true;
    }
    // 沒被追蹤的殘留高光（孤兒）也一起漸淡：按一次空白鍵就必須全部消失
    document.querySelectorAll('.gr-overlay:not(.gr-fading)').forEach((r) => { r.classList.add('gr-fading'); setTimeout(() => r.remove(), CFG.FADE_MS + 60); did = true; });
    return did;
  }

  /* ═════════════ 11. 空白鍵（最高優先）═════════════
   *  只要畫面上有高光，不論目前是什麼狀態（含校準中、再次中斷、控制組…），按空白鍵一定讓它漸淡。
   *  掛在 window 的 capture 階段（比頁面腳本更早）；有高光時 stopImmediatePropagation，不讓其他腳本搶走。
   *  在輸入框裡打字時：仍然讓高光漸淡，但不吃掉那個空白字元。
   */
  window.addEventListener('keydown', (e) => {
    if (e.code !== 'Space' || e.repeat) return;
    if (dead) return;
    const hasSpot = (!!overlayRoot && !overlayRoot.classList.contains('gr-fading')) || !!document.querySelector('.gr-overlay:not(.gr-fading)');
    const waiting = state === 'RETURNED' && !!session;
    if (!hasSpot && !waiting) return;
    const tg = e.target;
    const editable = tg && (tg.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(tg.tagName));
    if (hasSpot && !editable) { e.preventDefault(); e.stopImmediatePropagation(); }
    returnSeq++;
    fadeOverlay();
    if (waiting) {
      logTrial(session, performance.now(), hasSpot);
      session = null; state = 'READING';
      awayScore = 0; outReset(); lastFaceTs = performance.now(); resetSmooth(); gz.length = 0;
    }
  }, true);
  const outReset = () => { faceStreak = null; };

  /* ═════════════ 12. 實驗數據紀錄 ═════════════ */
  async function logTrial(s, endTs, shown) {
    const llm = s.llm || {};
    const rec = {
      time: new Date().toISOString(), url: location.href,
      subjectId: S.subjectId, distanceCm: S.distanceCm, userAngle: S.angleLabel,
      interruptReason: s.reason,
      awayMs: Math.round(s.returnTs - s.interruptedAt),
      recoveryMs: Math.round(endTs - s.returnTs),
      highlightShown: shown,
      highlightDelayMs: s.shownTs ? Math.round(s.shownTs - s.returnTs) : '',
      source: s.source, sentence: s.sentence || '',
      geometricSentence: s.ctx ? s.ctx.localSentence : '',
      gazeX: s.ctx ? Math.round(s.ctx.client.x) : '', gazeY: s.ctx ? Math.round(s.ctx.client.y) : '',
      corrType: corrState && corrState.model ? corrState.model.type : 'none', circleCm: S.circleCm,
      llmOk: !!llm.ok, llmLatencyMs: llm.rttMs || '', llmConfidence: llm.confidence != null ? llm.confidence : '', llmError: llm.error || '',
      reinterrupts: s.reinterrupts, lostSec: S.lostSec, angleDeg: S.angleDeg, headAngleDeg: S.headAngleDeg, awayDeg: S.awayDeg, opacity: S.opacity,
      ...devRec()
    };
    try {
      const { trials = [] } = await chrome.storage.local.get('trials');
      trials.push(rec);
      await chrome.storage.local.set({ trials: trials.slice(-5000) });
    } catch (e) { console.warn('[GR] 記錄失敗', e); }
  }

  /* ═════════════ 13. 校準（進度條 / 9 點，每次隨機；之後驗證 + 誤差修正 + 自動補強）═════════════
   *  同一時間只會有一個校準流程（token 互斥）：重新開始或鎖定時，舊流程會被中止並只清理自己的畫面，
   *  不會碰到新流程的鏡頭預覽與滑鼠訓練設定 → 不會互相衝突。
   *
   *  【進度條模式】最多 4 條：1 水平（最左→最右）、2 垂直（最上→最下）、3 底部水平（加強螢幕下方）、4 外斜（左上→右下）。
   *    一次只有「被指定的那一條」會前進，其他條淡出且不動。圓點沿著進度條移動，使用者用眼睛追隨；
   *    進度只在「臉在場、且視線估計大致在圓點附近」時前進（眼睛控制進度），視線離開則暫停。
   *    訓練標籤 = 120ms 前的目標位置（補償眼睛追隨的延遲），且只在使用者確實跟著時才訓練（避免錯誤標籤）。
   *    若連續 3 秒被擋住，放行 1.5 秒避免卡住。
   *  【9 點模式】3×3，每點點 3 下（底部一排在 93% 高度）。
   *  【驗證】12 個已知點（含 4 排高度，偏重下半部）→ 擬合誤差修正 → 誤差過大的點（>2.2 公分）自動補強（最多 3 點）。
   * ═══════════════════════════════════════════════════════════════ */
  function abortCalibration() {
    const tk = calibState.token;
    if (tk) { tk.aborted = true; tk.waiters.forEach((f) => f()); }
    calibState.token = null; calibSink = null;
    document.querySelectorAll('.gr-calib-layer').forEach((n) => n.remove());
  }

  const sleepT = (tk, ms) => new Promise((res) => { const id = setTimeout(res, ms); tk.waiters.push(() => { clearTimeout(id); res(); }); });
  const shuffle = (a) => { for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };
  const pickMode = () => (S.calibMode === 'bars' || S.calibMode === 'points') ? S.calibMode : (Math.random() < 0.5 ? 'bars' : 'points');

  async function startCalibration() {
    if (state === 'TESTING') return;
    abortCalibration();            // 互斥：中止舊流程
    clearOverlay();                // 舊高光不得殘留
    session = null;
    const token = { aborted: false, skipped: false, waiters: [] };
    calibState.token = token;
    state = 'CALIBRATING'; awayScore = 0; gz.length = 0;
    sendCmd('preview', { on: true });
    mouseSet(false);       // 校準期間標籤只來自我們自己送的訓練點，避免滑鼠位置污染

    const layer = document.createElement('div');
    layer.className = 'gr-root gr-calib-layer';
    const ui = { title: document.createElement('div'), sub: document.createElement('div') };
    ui.title.className = 'gr-calib-title'; ui.sub.className = 'gr-calib-sub';
    const skip = document.createElement('button');
    skip.type = 'button'; skip.className = 'gr-calib-skip'; skip.textContent = t('skipCalib');
    skip.addEventListener('click', () => { token.skipped = true; token.aborted = true; token.waiters.forEach((f) => f()); });
    layer.append(ui.title, ui.sub, skip);
    document.documentElement.appendChild(layer);

    let summary = null;
    try { summary = await calibrationFlow(token, layer, ui); }
    catch (e) { console.warn('[GR] 校準流程錯誤', e); }
    finally {
      layer.remove();
      if (calibState.token === token || calibState.token === null) {   // 只有「自己仍是目前流程」才還原全域設定
        calibState.token = null; calibSink = null;
        sendCmd('preview', { on: false });
        mouseSet(true);
        if ((!token.aborted || token.skipped) && state === 'CALIBRATING') {
          state = 'READING'; lastFaceTs = performance.now(); faceStreak = null; awayScore = 0; gazeDrift = false;
          resetPoseBaseline(); resetSmooth(); gz.length = 0;
          if (!token.skipped && summary) saveProfileNow();      // 校準完成 → 存成校準檔（換 PDF / 新分頁 / 重開瀏覽器都直接沿用）
          toast(token.skipped ? t('calibSkipped') : (summary ? t(summary.fixed ? 'calibResult' : 'calibResultNoFix', summary) + ' · ' + t('calibQuality', summary) : t('toastTracking')), 8000);
          if (summary && devQ.fps && devQ.fps < 12) setTimeout(() => toast(t('lowFps', { fps: Math.round(devQ.fps) }), 9000), 8200);   // 太慢：提醒改善
        }
      }
    }
  }

  async function calibrationFlow(token, layer, ui) {
    const mode = pickMode();
    if (mode === 'bars') await barPhase(token, layer, ui); else await pointPhase(token, layer, ui);
    if (token.aborted) return null;

    // 驗證（12 個已知點，偏重下半部）→ 擬合修正 → 補強
    const g = [0.1, 0.5, 0.9], rowsY = [0.1, 0.4, 0.7, 0.93];
    const targets = shuffle(rowsY.flatMap((py) => g.map((px) => [px * innerWidth, py * innerHeight])));
    const rows = [];
    for (let i = 0; i < targets.length && !token.aborted; i++) {
      ui.title.textContent = t('calibValTitle'); ui.sub.textContent = t('calibValProgress', { n: i + 1, total: targets.length });
      rows.push(await collectAt(token, layer, ui, targets[i][0], targets[i][1]));
    }
    if (token.aborted) return null;

    let fit = fitCorrection(rows);
    const limit = CFG.WEAK_CM * pxPerCm();
    const med = median(fit.perTarget.filter((e) => e != null).concat([0]));
    const weak = fit.perTarget.map((e, i) => ({ e, i })).filter((o) => o.e != null && o.e > Math.max(limit, 1.8 * med)).sort((a, b) => b.e - a.e).slice(0, 3);
    for (const w of weak) {
      if (token.aborted) return null;
      ui.title.textContent = t('calibRefineTitle', { k: CFG.CLICKS }); ui.sub.textContent = '';
      await clickDot(token, layer, rows[w.i].tx, rows[w.i].ty, CFG.CLICKS);
      if (token.aborted) return null;
      ui.title.textContent = t('calibValTitle');
      rows[w.i] = await collectAt(token, layer, ui, rows[w.i].tx, rows[w.i].ty);
    }
    if (weak.length) fit = fitCorrection(rows);

    corrState = fit.model ? { model: fit.model, W: innerWidth, H: innerHeight, ts: Date.now() } : null;
    const nz = rows.filter((r) => r.rx != null && r.noise != null).map((r) => r.noise);
    if (nz.length >= 3) devQ.noisePx = median(nz);
    const nValid = rows.filter((r) => r.rx != null).length;
    devQ.errPx = nValid >= 3 ? (fit.model ? fit.fitPx : fit.rawPx) : null; adCache = null;
    try {
      const { accuracy = [] } = await chrome.storage.local.get('accuracy');
      const ppc = pxPerCm(), dist = S.distanceCm || CFG.VIEW_DISTANCE_CM;
      const logRows = rows.map((r, i) => ({
        time: new Date().toISOString(), phase: 'calib-validation', calibMode: mode, corrType: fit.type, subjectId: S.subjectId, distanceCm: dist, userAngle: S.angleLabel,
        screenDiagIn: S.screenDiagIn, pointIdx: i, targetX: Math.round(r.tx), targetY: Math.round(r.ty),
        estX: r.rx == null ? '' : Math.round(r.rx), estY: r.ry == null ? '' : Math.round(r.ry),
        errPx: r.rx == null ? '' : Math.round(Math.hypot(r.rx - r.tx, r.ry - r.ty)),
        errDeg: r.rx == null ? '' : +(Math.atan(Math.hypot(r.rx - r.tx, r.ry - r.ty) / ppc / dist) * 180 / Math.PI).toFixed(2),
        errCorrectedLooPx: fit.perTarget[i] == null ? '' : Math.round(fit.perTarget[i]),
        validRate: r.validRate, frames: r.n, weakRefined: weak.some((w) => w.i === i), noisePointPx: r.noise == null ? '' : Math.round(r.noise),
        ...devRec()
      }));
      await chrome.storage.local.set({ accuracy: accuracy.concat(logRows).slice(-20000) });
    } catch (e) { console.warn('[GR] 儲存校準資料失敗', e); }
    const ppc = pxPerCm();
    const okv = rows.some((r) => r.rx != null);
    return { fixed: !!fit.model, cm: okv ? (fit.fitPx / ppc).toFixed(2) : '?', raw: okv ? (fit.rawPx / ppc).toFixed(2) : '?',
      noise: devQ.noisePx != null ? (devQ.noisePx / ppc).toFixed(2) : '?', fps: devQ.fps ? Math.round(devQ.fps) : '?', cam: devQ.camH ? devQ.camW + '×' + devQ.camH : '?' };
  }

  /* ── 進度條模式 ── */
  async function barPhase(token, layer, ui) {
    const W = innerWidth, H = innerHeight, m = 0.06;
    const defs = [
      { x0: m * W, y0: .5 * H, x1: (1 - m) * W, y1: .5 * H },       // 1：x 軸，最左 → 最右
      { x0: .5 * W, y0: m * H, x1: .5 * W, y1: (1 - m) * H },       // 2：y 軸，最上 → 最下
      { x0: m * W, y0: .9 * H, x1: (1 - m) * W, y1: .9 * H },       // 3：底部水平（螢幕下方加強）
      { x0: m * W, y0: .08 * H, x1: (1 - m) * W, y1: .92 * H }      // 4：外斜，左上 → 右下
    ];
    const bars = defs.slice(0, clamp(parseInt(S.barCount, 10) || 4, 1, 4));
    const NS = 'http://www.w3.org/2000/svg';
    const svg = document.createElementNS(NS, 'svg');
    svg.setAttribute('class', 'gr-bars'); svg.setAttribute('width', W); svg.setAttribute('height', H);
    const els = bars.map((b) => {
      const g = document.createElementNS(NS, 'g'), mk = (tag, cls) => { const e = document.createElementNS(NS, tag); e.setAttribute('class', cls); g.appendChild(e); return e; };
      const track = mk('line', 'track'), fill = mk('line', 'fill'), dot = mk('circle', 'dot');
      for (const l of [track, fill]) { l.setAttribute('x1', b.x0); l.setAttribute('y1', b.y0); l.setAttribute('x2', b.x1); l.setAttribute('y2', b.y1); }
      b.len = Math.hypot(b.x1 - b.x0, b.y1 - b.y0);
      fill.setAttribute('stroke-dasharray', b.len); fill.setAttribute('stroke-dashoffset', b.len);
      dot.setAttribute('r', 13); dot.setAttribute('cx', b.x0); dot.setAttribute('cy', b.y0); dot.style.display = 'none';
      svg.appendChild(g);
      return { g, fill, dot };
    });
    layer.insertBefore(svg, layer.firstChild);
    let trained = 0;

    for (let bi = 0; bi < bars.length && !token.aborted; bi++) {
      const bar = bars[bi], el = els[bi];
      els.forEach((e, i) => e.g.classList.toggle('active', i === bi));      // 只有被指定的這一條亮起、前進
      el.dot.style.display = '';
      ui.title.textContent = t('calibBarTitle');
      const label = t('calibBarProgress', { n: bi + 1, total: bars.length });
      ui.sub.textContent = label;
      let p = 0, last = performance.now(), blockedSince = null, reliefUntil = 0, lastTrain = 0;
      const path = [];
      await new Promise((resolve) => {
        token.waiters.push(resolve);
        const tick = () => {
          if (token.aborted) return resolve();
          const now = performance.now(), dt = Math.min(100, now - last); last = now;
          const tx = bar.x0 + (bar.x1 - bar.x0) * p, ty = bar.y0 + (bar.y1 - bar.y0) * p;
          // 眼睛控制進度：臉在場，且（模型已有基本訓練後）視線估計大致在目標附近才前進
          const faceOk = now - lastFaceTs < 400;
          let near = true;
          if (trained >= 25 && rawRecent.length >= 3) {
            const r = rawRecent.slice(-5), gx = median(r.map((s) => s.x)), gy = median(r.map((s) => s.y));
            near = Math.hypot(gx - tx, gy - ty) <= (bi === 0 ? 0.3 : 0.2) * Math.hypot(W, H);
          }
          const ok = faceOk && near;
          if (ok || now < reliefUntil) { p = Math.min(1, p + CFG.BAR_SPEED * dt / 1000); blockedSince = null; }
          else if (blockedSince === null) blockedSince = now;
          else if (now - blockedSince > 3000) { reliefUntil = now + 1500; blockedSince = null; }     // 防卡住
          ui.sub.textContent = (ok || now < reliefUntil) ? label : t('calibBarHold');
          path.push({ t: now, x: tx, y: ty });
          while (path.length > 20) path.shift();
          if (ok && now - lastTrain >= 100) {                                                         // 10Hz 訓練（相鄰樣本幾乎相同，更密只會浪費模型的 400 筆視窗）
            const lab = path.slice().reverse().find((q) => q.t <= now - CFG.TRAIN_LAG_MS) || path[0];
            train(lab.x, lab.y); trained++; lastTrain = now;
          }
          el.fill.setAttribute('stroke-dashoffset', bar.len * (1 - p));
          el.dot.setAttribute('cx', tx); el.dot.setAttribute('cy', ty);
          if (p >= 1) return resolve();
          setTimeout(tick, 33);
        };
        tick();
      });
    }
  }

  /* ── 9 點模式（每點 3 下）── */
  async function pointPhase(token, layer, ui) {
    const W = innerWidth, H = innerHeight;
    const pts = shuffle([.08, .5, .92].flatMap((py0, r) => [.08, .5, .92].map((px) => [px, r === 2 ? .93 : py0])));
    for (let i = 0; i < pts.length && !token.aborted; i++) {
      ui.title.textContent = t('calibPointTitle', { k: CFG.CLICKS });
      ui.sub.textContent = t('calibPointProgress', { n: i + 1, total: pts.length });
      await clickDot(token, layer, pts[i][0] * W, pts[i][1] * H, CFG.CLICKS);
    }
  }

  /** 顯示一個要點擊 k 次的圓點；每次點擊後連續送幾筆訓練樣本（眼睛正盯著它） */
  function clickDot(token, layer, x, y, clicks) {
    return new Promise((resolve) => {
      const b = document.createElement('button');
      b.type = 'button'; b.className = 'gr-cal-dot';
      b.style.left = x + 'px'; b.style.top = y + 'px'; b.style.setProperty('--p', 0);
      layer.appendChild(b);
      let c = 0;
      const end = () => { b.remove(); resolve(); };
      token.waiters.push(end);
      b.addEventListener('click', () => {
        if (c >= clicks || token.aborted) return;
        c++; b.style.setProperty('--p', c / clicks);
        for (let k = 0; k < 5; k++) setTimeout(() => { if (!token.aborted) train(x, y); }, k * 70);
        if (c >= clicks) { b.classList.add('done'); setTimeout(end, 450); }
      });
    });
  }

  /**
   * 驗證：顯示小圓點，請使用者注視它、不要點擊。採「自己跑」的定時收集（不必等系統偵測到你在看）：
   *  每點先等 0.7 秒讓眼睛移到圓點上（避免把還在移動途中的視線算進去），再連續收集 1.2 秒，取中位數當這一點的估計位置。
   *  臉不在畫面時暫停計時（最多多等 6 秒，之後跳過這一點），所以不會卡住。
   *  視線中位數離目標超過 45% 對角線（顯然沒在看）的點不拿來擬合誤差修正。
   */
  async function collectAt(token, layer, ui, tx, ty) {
    const dot = document.createElement('div');
    dot.className = 'gr-cal-dot val'; dot.style.left = tx + 'px'; dot.style.top = ty + 'px';
    layer.appendChild(dot);
    const label = ui.sub.textContent;
    const buf = [];
    calibSink = (d) => buf.push({ x: d.x, y: d.y, face: d.face, t: performance.now() });
    const diag = Math.hypot(innerWidth, innerHeight);
    const SETTLE = 700, COLLECT = 1200, GIVEUP = 6000;
    const t0 = performance.now();
    let active = 0, last = t0, ok = false;
    await new Promise((resolve) => {
      token.waiters.push(resolve);
      const tick = () => {
        if (token.aborted) return resolve();
        const now = performance.now(), dt = Math.min(100, now - last); last = now;
        const win = buf.filter((s) => now - s.t <= 600);       // 只看「比例」，不看張數：效能差的筆電（每秒不到 10 張）也能正常前進
        const faceOk = win.length >= 2 && win.filter((s) => s.face && s.x != null).length / win.length >= 0.6;
        if (faceOk) active += dt;                                   // 只有臉在畫面時才計時
        dot.style.setProperty('--p', Math.min(1, active / (SETTLE + COLLECT)));
        ui.sub.textContent = (faceOk || now - t0 < 1500) ? label : t('calibValHold');
        if (active >= SETTLE + COLLECT) { ok = true; return resolve(); }
        if (now - t0 > GIVEUP + SETTLE + COLLECT) return resolve();
        setTimeout(tick, 33);
      };
      tick();
    });
    calibSink = null;
    if (ok && !token.aborted) { dot.classList.add('found'); await sleepT(token, 150); }
    dot.remove(); ui.sub.textContent = label;
    const end = performance.now(), used = buf.filter((s) => end - s.t <= COLLECT + 150);
    const valid = used.filter((s) => s.face && s.x != null);
    const row = { tx, ty, rx: null, ry: null, noise: null, n: used.length, validRate: used.length ? +(valid.length / used.length).toFixed(3) : 0 };
    if (ok && valid.length >= 5) {
      const rx = median(valid.map((s) => s.x)), ry = median(valid.map((s) => s.y));
      row.noise = 1.4826 * Math.hypot(median(valid.map((s) => Math.abs(s.x - rx))), median(valid.map((s) => Math.abs(s.y - ry))));   // 盯著同一點時的散布＝這台電腦的雜訊
      if (Math.hypot(rx - tx, ry - ty) <= 0.45 * diag) { row.rx = rx; row.ry = ry; }     // 離目標太遠＝顯然沒在看這個點，不拿來擬合修正
    }
    return row;
  }

  /* ═════════════ 14. 眼動準確度測試 ═════════════ */
  function summarizePoint(idx, tx, ty, samples, distCm) {
    const valid = samples.filter((s) => s.face), ppc = pxPerCm();
    const row = {
      time: new Date().toISOString(), phase: 'accuracy-test', corrType: corrState && corrState.model ? corrState.model.type : 'none',
      subjectId: S.subjectId, distanceCm: distCm, userAngle: S.angleLabel, screenDiagIn: S.screenDiagIn,
      pointIdx: idx, targetX: Math.round(tx), targetY: Math.round(ty), estX: '', estY: '', errPx: '', errRawPx: '', errDeg: '', dispersionPx: '',
      validRate: samples.length ? +(valid.length / samples.length).toFixed(3) : 0, frames: samples.length,
      ...devRec()
    };
    if (valid.length >= 3) {
      const ex = median(valid.map((s) => s.x)), ey = median(valid.map((s) => s.y));
      const mx = valid.reduce((a, s) => a + s.x, 0) / valid.length, my = valid.reduce((a, s) => a + s.y, 0) / valid.length;
      const err = Math.hypot(ex - tx, ey - ty);
      row.estX = Math.round(ex); row.estY = Math.round(ey); row.errPx = Math.round(err);
      row.errRawPx = Math.round(Math.hypot(median(valid.map((s) => s.rx)) - tx, median(valid.map((s) => s.ry)) - ty));   // 未修正的原始誤差，用來證明修正有效
      row.errDeg = +(Math.atan(err / ppc / distCm) * 180 / Math.PI).toFixed(2);
      row.dispersionPx = Math.round(valid.reduce((a, s) => a + Math.hypot(s.x - mx, s.y - my), 0) / valid.length);
    }
    return row;
  }

  async function startAccuracyTest() {
    if (state !== 'READING' || paused) { toast(t('accNeedCal'), 3500); return; }
    state = 'TESTING'; accAbort = false;
    mouseSet(false);
    const SETTLE = 1000, COLLECT = 1500, g = [0.1, 0.5, 0.9], pts = [];
    for (const py of g) for (const px of g) pts.push([px, py]);
    shuffle(pts);
    const layer = document.createElement('div');
    layer.className = 'gr-root gr-acc-layer';
    layer.innerHTML = '<div class="gr-acc-dot"></div><div class="gr-acc-msg"></div>';
    layer.querySelector('.gr-acc-msg').textContent = t('accMsg');
    document.documentElement.appendChild(layer);
    const dot = layer.firstChild;
    const onKey = (e) => { if (e.key === 'Escape') accAbort = true; };
    document.addEventListener('keydown', onKey, true);
    const dist = S.distanceCm || CFG.VIEW_DISTANCE_CM, rows = [];
    for (let i = 0; i < pts.length && !accAbort; i++) {
      const tx = pts[i][0] * innerWidth, ty = pts[i][1] * innerHeight;
      dot.style.left = tx + 'px'; dot.style.top = ty + 'px';
      accCollecting = false; await sleep(SETTLE);
      accSamples = []; accCollecting = true; await sleep(COLLECT);
      accCollecting = false;
      rows.push(summarizePoint(i, tx, ty, accSamples, dist));
    }
    document.removeEventListener('keydown', onKey, true);
    layer.remove();
    mouseSet(true);
    if (state === 'TESTING') { state = 'READING'; lastFaceTs = performance.now(); faceStreak = null; awayScore = 0; gz.length = 0; }
    if (accAbort) { toast(t('accAborted')); return; }
    try {
      const { accuracy = [] } = await chrome.storage.local.get('accuracy');
      await chrome.storage.local.set({ accuracy: accuracy.concat(rows).slice(-20000) });
    } catch (e) { console.warn('[GR] 儲存準確度失敗', e); }
    const ok = rows.filter((r) => r.errDeg !== '');
    const mean = (k) => ok.length ? (ok.reduce((a, r) => a + r[k], 0) / ok.length) : NaN;
    const vr = rows.reduce((a, r) => a + r.validRate, 0) / rows.length;
    toast(ok.length ? t('accSummary', { deg: mean('errDeg').toFixed(2), px: Math.round(mean('errPx')), rate: Math.round(vr * 100) }) : t('accNoFace'), 6000);
  }

  /* ═════════════ 15. 提示 ═════════════ */
  let toastTimer = null;
  function toast(msg, ms = 2500) {
    let el = document.querySelector('.gr-toast');
    if (!el) { el = document.createElement('div'); el.className = 'gr-root gr-toast'; document.documentElement.appendChild(el); }
    el.textContent = msg; el.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.classList.remove('show'), ms);
  }
})();
