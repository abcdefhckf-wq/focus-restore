/**
 * viewer-pre.js — 必須在 content.js 之前載入。
 * 告訴 content.js：這是 PDF 閱讀器，而且捲動發生在 #viewerContainer（不是整個視窗）。
 * content.js 會把「容器捲動量」計入文件座標，並用 PDF 文字層（.textLayer）當作閱讀區塊。
 */
window.__GR_PDF = true;
window.__GR_SCROLLER = document.getElementById('viewerContainer');
